"""
Tradres API — Erzurum ilçe kataloğu ve açık adres zenginleştirme.
https://api.tradres.com.tr
"""

from __future__ import annotations

import math
import os
from functools import lru_cache
from typing import Any, Optional

import requests
from fastapi import HTTPException

TRADRES_API_KEY = os.getenv(
    "TRADRES_API_KEY", "trd_live_wBW4BALd3cCaJJgrsXEYb6o2TqngUS7h"
)
TRADRES_PROVIDERS_URL = "https://api.tradres.com.tr/public/v1/catalog/providers"
TRADRES_NODES_URL = (
    "https://api.tradres.com.tr/public/v1/catalog/providers/localsqlite/nodes"
)
ERZURUM_PROVINCE_ID = 25
TRADRES_HEADERS = {
    "X-Api-Key": TRADRES_API_KEY,
    "Accept": "application/json",
}

# Erzurum ilçe merkezleri (yaklaşık) — koordinattan ilçe tahmini
ERZURUM_TOWN_CENTERS: dict[str, tuple[float, float]] = {
    "YAKUTIYE": (39.9055, 41.2658),
    "PALANDOKEN": (39.8850, 41.2750),
    "AZIZIYE": (39.9560, 41.1120),
    "HORASAN": (40.0380, 41.4510),
    "OLTU": (40.5480, 41.9980),
    "PASINLER": (39.9770, 41.6770),
    "HINIS": (39.3600, 41.7000),
    "KARAYAZI": (39.6940, 42.1420),
    "TEKMAN": (39.6440, 41.5050),
    "KARAÇOBAN": (39.3430, 42.6080),
    "AŞKALE": (39.9210, 40.6900),
    "ÇAT": (39.6080, 40.9780),
    "İSPİR": (40.4800, 40.9950),
    "NARMAN": (40.3450, 41.8650),
    "OLUR": (40.8270, 42.1300),
    "ŞENKAYA": (40.5560, 42.3430),
    "TORTUM": (40.2980, 41.5500),
    "UZUNDERE": (40.5320, 41.5380),
    "KÖPRÜKÖY": (39.9650, 41.8680),
    "PAZARYOLU": (40.1670, 40.7670),
}


def _norm_key(name: str) -> str:
    tr = str.maketrans("ıİğĞüÜşŞöÖçÇ", "iIgGuUsSoOcC")
    return name.upper().translate(tr).replace(" ", "")


def get_erzurum_providers() -> Any:
    """Kullanıcı örneğindeki gibi Tradres sağlayıcı kataloğunu döndürür."""
    try:
        response = requests.get(TRADRES_PROVIDERS_URL, headers=TRADRES_HEADERS, timeout=15)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as exc:
        raise HTTPException(
            status_code=500, detail=f"Tradres API hatası: {exc}"
        ) from exc


@lru_cache(maxsize=1)
def get_erzurum_towns_cached() -> tuple[dict[str, Any], ...]:
    """Erzurum ilçeleri (parentId=25) — bellek önbelleği."""
    try:
        response = requests.get(
            TRADRES_NODES_URL,
            headers=TRADRES_HEADERS,
            params={"level": "town", "parentId": ERZURUM_PROVINCE_ID, "take": 200},
            timeout=15,
        )
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, list):
            return tuple()
        return tuple(data)
    except requests.exceptions.RequestException:
        return tuple()


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(p1) * math.cos(p2) * math.sin(dlon / 2) ** 2
    )
    return 2 * r * math.asin(math.sqrt(a))


def guess_town_name(lat: float, lon: float) -> str:
    """Koordinata en yakın Erzurum ilçesi (Tradres + sabit merkezler)."""
    towns = get_erzurum_towns_cached()
    best_name = "Yakutiye"
    best_dist = 1e9

    for town in towns:
        name = (town.get("name") or "").strip()
        if not name:
            continue
        key = _norm_key(name)
        center = ERZURUM_TOWN_CENTERS.get(key)
        if not center:
            continue
        d = _haversine_km(lat, lon, center[0], center[1])
        if d < best_dist:
            best_dist = d
            best_name = name.title()

    return best_name


def match_town_from_tags(tags: dict[str, Any], towns: tuple[dict, ...]) -> Optional[str]:
    """OSM addr:district / suburb ile Tradres ilçe adını eşleştirir."""
    raw = (
        tags.get("addr:district")
        or tags.get("addr:suburb")
        or tags.get("addr:city")
        or ""
    )
    if not raw:
        return None
    key = _norm_key(raw)
    for town in towns:
        name = (town.get("name") or "").strip()
        if not name:
            continue
        nk = _norm_key(name)
        if nk in key or key in nk:
            return name.title()
    return None


def enrich_open_address(
    tags: dict[str, Any],
    lat: float,
    lon: float,
    base_address: str,
) -> tuple[str, str]:
    """
    Tradres ilçe bilgisi ile tam açık adres.
    Dönüş: (mahalle, acik_adres)
    """
    towns = get_erzurum_towns_cached()
    town = match_town_from_tags(tags or {}, towns) or guess_town_name(lat, lon)

    suburb = (
        (tags or {}).get("addr:suburb")
        or (tags or {}).get("addr:neighbourhood")
        or (tags or {}).get("addr:hamlet")
        or ""
    )
    suburb = " ".join(str(suburb).split()).strip()
    if suburb and "mahalle" not in suburb.lower():
        mahalle = f"{suburb} Mahallesi"
    elif suburb:
        mahalle = suburb
    else:
        mahalle = f"{town} Merkez"

    low = (base_address or "").lower()
    if town.lower() not in low:
        acik = f"{base_address}, {town}, Erzurum, Türkiye"
    elif "türkiye" not in low:
        acik = f"{base_address}, Türkiye"
    else:
        acik = base_address

    return mahalle[:100], acik[:500]
