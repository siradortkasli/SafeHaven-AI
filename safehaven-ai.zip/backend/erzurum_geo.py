"""
Erzurum il sınır kutusu ve deprem riski bina filtreleri.
WPF haritası: merkez 39.9055, 41.2658
"""

# Overpass / API ortak bbox (güney, batı, kuzey, doğu)
ERZURUM_LAT_MIN = 39.72
ERZURUM_LAT_MAX = 39.98
ERZURUM_LON_MIN = 41.05
ERZURUM_LON_MAX = 41.55
ERZURUM_BBOX_OVERPASS = f"{ERZURUM_LAT_MIN},{ERZURUM_LON_MIN},{ERZURUM_LAT_MAX},{ERZURUM_LON_MAX}"
ERZURUM_IL_ADI = "Erzurum"

# Deprem risk değerlendirmesine dahil edilmeyecek OSM yapı tipleri
EXCLUDED_BUILDING_TYPES = frozenset({
    "mosque", "church", "chapel", "cathedral", "bunker", "static", "roof",
    "construction", "garage", "shed", "ruins", "greenhouse", "farm_auxiliary",
    "cabin", "hangar", "bridge", "service", "kiosk", "toilets", "storage_tank",
})

# Öncelikli risk binaları (konut / kamu / iş yeri)
RISK_BUILDING_TYPES = frozenset({
    "yes", "residential", "apartments", "apartment", "house", "detached",
    "terrace", "dormitory", "school", "university", "college", "hospital",
    "commercial", "retail", "office", "public", "civic", "hotel", "industrial",
    "warehouse", "kindergarten",
})


def is_in_erzurum_bbox(lat: float, lon: float) -> bool:
    try:
        lat_f, lon_f = float(lat), float(lon)
    except (TypeError, ValueError):
        return False
    if lat_f == 0.0 and lon_f == 0.0:
        return False
    return (
        ERZURUM_LAT_MIN <= lat_f <= ERZURUM_LAT_MAX
        and ERZURUM_LON_MIN <= lon_f <= ERZURUM_LON_MAX
    )


def is_deprem_risk_building(tags: dict) -> bool:
    """OSM etiketlerine göre deprem riski değerlendirmesine uygun yapı mı?"""
    if not tags:
        return False

    btype = (tags.get("building") or "yes").lower().strip()
    if btype in EXCLUDED_BUILDING_TYPES:
        return False

    amenity = (tags.get("amenity") or "").lower()
    if amenity in ("place_of_worship", "grave_yard", "parking"):
        return False

    if tags.get("ruins") == "yes" or tags.get("abandoned") == "yes":
        return False

    # building=yes veya bilinen risk kategorileri
    if btype in RISK_BUILDING_TYPES:
        return True

    # İsimli konut/iş yapıları (building=yes olmayan nadir durumlar)
    if tags.get("addr:street") or tags.get("addr:housenumber"):
        return btype not in EXCLUDED_BUILDING_TYPES

    return btype == "yes"


def erzurum_sql_where(alias: str = "") -> str:
    """SQL WHERE parçası — yalnızca Erzurum bbox içi kayıtlar."""
    p = f"{alias}." if alias else ""
    return (
        f"{p}enlem BETWEEN {ERZURUM_LAT_MIN} AND {ERZURUM_LAT_MAX} "
        f"AND {p}boylam BETWEEN {ERZURUM_LON_MIN} AND {ERZURUM_LON_MAX} "
        f"AND ({p}enlem != 0 OR {p}boylam != 0)"
    )
