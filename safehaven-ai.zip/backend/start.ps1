# SafeHaven Backend — doğru klasörden başlat
Set-Location $PSScriptRoot

if (-not (Test-Path "database.db")) {
    Write-Host "[1/3] Veritabani olusturuluyor..." -ForegroundColor Yellow
    python init_db.py
}

Write-Host "[2/3] Erzurum verileri cekiliyor (OSM + Kandilli)..." -ForegroundColor Yellow
python -c "from db_security import open_secure_connection; from data_sync import bootstrap_erzurum_data; c=open_secure_connection('database.db'); print(bootstrap_erzurum_data(c, force=True))"

Write-Host "[3/3] API baslatiliyor: http://127.0.0.1:8000" -ForegroundColor Green
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
