from ai_agent import generate_earthquake_ai_summary

earthquakes = [
    {
        "location": "Aziziye-Erzurum",
        "magnitude": 2.8,
        "depth": 7.2
    },
    {
        "location": "Yakutiye-Erzurum",
        "magnitude": 3.7,
        "depth": 5.1
    },
    {
        "location": "Pasinler-Erzurum",
        "magnitude": 4.1,
        "depth": 8.4
    }
]

summary = generate_earthquake_ai_summary(
    earthquakes,
    city_name="Erzurum"
)

print(summary)