from ai_agent import generate_city_ai_summary

buildings = [
    {
        "id": 1,
        "mahalle": "Yakutiye",
        "risk_level": "Acil Müdahale",
        "yasli_sayisi": 5,
        "engelli_sayisi": 2,
        "cocuk_sayisi": 3
    },
    {
        "id": 2,
        "mahalle": "Palandöken",
        "risk_level": "Yüksek Risk",
        "yasli_sayisi": 3,
        "engelli_sayisi": 1,
        "cocuk_sayisi": 4
    },
    {
        "id": 3,
        "mahalle": "Aziziye",
        "risk_level": "Düşük Risk",
        "yasli_sayisi": 1,
        "engelli_sayisi": 0,
        "cocuk_sayisi": 2
    }
]

safe_zones = [
    {
        "id": 1,
        "ad": "Yakutiye Kent Meydanı",
        "kapasite": 500,
        "doluluk": 420
    },
    {
        "id": 2,
        "ad": "Atatürk Üniversitesi Açık Alanı",
        "kapasite": 1500,
        "doluluk": 300
    }
]

earthquakes = [
    {
        "location": "Yakutiye-Erzurum",
        "magnitude": 3.7
    },
    {
        "location": "Pasinler-Erzurum",
        "magnitude": 2.4
    }
]

summary = generate_city_ai_summary(
    buildings,
    safe_zones,
    earthquakes,
    city_name="Erzurum"
)

print(summary)