from ai_agent import generate_full_report

building = {
    "id": 1,
    "mahalle": "Yakutiye",
    "adres": "Cumhuriyet Caddesi No:12",
    "bina_yasi": 42,
    "kat_sayisi": 8,
    "zemin_riski": 5,
    "hasar_durumu": 4,
    "yasli_sayisi": 5,
    "engelli_sayisi": 2,
    "cocuk_sayisi": 3,
    "enlem": 39.9043,
    "boylam": 41.2679
}

safe_zones = [
    {
        "id": 1,
        "ad": "Yakutiye Kent Meydanı Toplanma Alanı",
        "mahalle": "Yakutiye",
        "adres": "Kent Meydanı",
        "enlem": 39.9051,
        "boylam": 41.2702,
        "kapasite": 500,
        "doluluk": 120,
        "engelli_uygun": 1
    },
    {
        "id": 2,
        "ad": "Atatürk Üniversitesi Açık Alanı",
        "mahalle": "Yakutiye",
        "adres": "Üniversite Kampüsü",
        "enlem": 39.8910,
        "boylam": 41.2365,
        "kapasite": 1500,
        "doluluk": 300,
        "engelli_uygun": 1
    },
    {
        "id": 3,
        "ad": "Engelli Erişimine Uygun Olmayan Yakın Alan",
        "mahalle": "Yakutiye",
        "adres": "Örnek Sokak Açık Alan",
        "enlem": 39.9045,
        "boylam": 41.2681,
        "kapasite": 300,
        "doluluk": 50,
        "engelli_uygun": 0
    }
]

risk_score = 132
risk_level = "Acil Müdahale"

report = generate_full_report(
    building,
    risk_score,
    risk_level,
    safe_zones
)

print("\n========== SAFEHAVEN AI TEST ==========\n")

print("RİSK SKORU:")
print(report["risk_score"])

print("\nRİSK SEVİYESİ:")
print(report["risk_level"])

print("\nAI ANALİZ:")
print(report["ai_analysis"])

print("\nAKSİYON PLANI:")
print(report["action_plan"])

print("\nETİK KONTROL:")
print(report["ethics_check"])

print("\nVATANDAŞ MESAJI:")
print(report["citizen_message"])

print("\nSEÇİLEN GÜVENLİ ALAN:")
print(report["selected_safe_zone"])

print("\nGÜVENLİ ALAN AI AÇIKLAMASI:")
print(report["safe_zone_explanation"])

print("\nGÜVENLİ ALAN VATANDAŞ MESAJI:")
print(report["safe_zone_message"])

print("\n========== TEST BİTTİ ==========\n")