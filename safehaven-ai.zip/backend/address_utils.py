"""
OSM etiketleri ve Nominatim ile tam açık adres üretimi.
"""

from __future__ import annotations

import json
import time
import urllib.parse
import urllib.request
from typing import Any, Optional

NOMINATIM_URL = "https://nominatim.openstreetmap.org/reverse"
NOMINATIM_HEADERS = {
    "User-Agent": "SafeHaven-AI/3.0 (Erzurum Afet Yonetimi)",
    "Accept-Language": "tr",
}
ERZURUM_CITY = "Erzurum"


def _clean(part: str) -> str:
    return " ".join((part or "").split()).strip()


def is_incomplete_open_address(adres: str) -> bool:
    """Kısa veya mahalle+il formatındaki eksik adresleri tespit eder."""
    if not adres or len(adres.strip()) < 35:
        return True
    low = adres.lower().strip()
    if low in ("erzurum, türkiye", "erzurum,türkiye", "yakutiye, erzurum", "yakutiye,erzurum"):
        return True
    if low.count(",") <= 1:
        return True
    # "Yakutiye, Erzurum" veya "Pollat X, Yakutiye, Erzurum" gibi kısa kalıplar
    if low.count(",") <= 2 and "erzurum" in low and "türkiye" not in low:
        return True
    if adres.strip().endswith("Erzurum") and len(adres) < 50:
        return True
    # Sokak/cadde veya No: içermeyen çok kısa tam adresler
    has_detail = any(
        x in low
        for x in (" cad", " sok", " mah", " bulvar", " no:", " no ", " sk.", " cd.")
    )
    if len(adres) < 55 and not has_detail:
        return True
    return False


def format_open_address_from_tags(tags: dict[str, Any]) -> str:
    """
    OSM etiketlerinden virgüllü tam açık adres (Nominatim benzeri).
    Örnek: Atatürk Caddesi No:12, Kurtuluş Mahallesi, Yakutiye, Erzurum, Türkiye
    """
    street = _clean(tags.get("addr:street", ""))
    num = _clean(tags.get("addr:housenumber", ""))
    suburb = _clean(
        tags.get("addr:suburb")
        or tags.get("addr:neighbourhood")
        or tags.get("addr:hamlet")
        or ""
    )
    district = _clean(tags.get("addr:district") or tags.get("addr:quarter") or "")
    city = _clean(tags.get("addr:city") or tags.get("addr:province") or ERZURUM_CITY)
    postcode = _clean(tags.get("addr:postcode", ""))
    name = _clean(tags.get("name", ""))

    if tags.get("addr:full"):
        full = _clean(tags["addr:full"])
        if "türkiye" not in full.lower():
            full = f"{full}, Türkiye"
        return full[:500]

    parts: list[str] = []
    if street and num:
        parts.append(f"{street} No:{num}")
    elif street:
        parts.append(street)
    elif name:
        parts.append(name)

    if suburb:
        if "mahalle" not in suburb.lower() and "mah." not in suburb.lower():
            parts.append(f"{suburb} Mahallesi")
        else:
            parts.append(suburb)
    if district and district not in parts:
        parts.append(district)
    if postcode:
        parts.append(postcode)
    if city and city not in parts:
        parts.append(city)
    parts.append("Türkiye")

    return ", ".join(parts)[:500]


def reverse_geocode(lat: float, lon: float, *, retries: int = 3) -> Optional[dict[str, str]]:
    """Nominatim ile tam display_name (açık adres). 429 için yeniden dener."""
    params = urllib.parse.urlencode(
        {
            "lat": f"{lat:.6f}",
            "lon": f"{lon:.6f}",
            "format": "json",
            "addressdetails": "1",
            "accept-language": "tr",
            "zoom": "18",
        }
    )
    url = f"{NOMINATIM_URL}?{params}"
    req = urllib.request.Request(url, headers=NOMINATIM_HEADERS)
    last_err: Optional[Exception] = None
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())
            break
        except Exception as exc:
            last_err = exc
            code = getattr(exc, "code", None)
            if code == 429 or "429" in str(exc):
                time.sleep(8.0 * (attempt + 1))
                continue
            return None
    else:
        return None

    display = _clean(data.get("display_name", ""))
    if not display:
        return None

    addr = data.get("address") or {}
    mahalle = _clean(
        addr.get("suburb")
        or addr.get("neighbourhood")
        or addr.get("quarter")
        or addr.get("city_district")
        or addr.get("town")
        or "Yakutiye"
    )
    return {"mahalle": mahalle, "acik_adres": display}


def reverse_geocode_cached(
    conn,
    lat: float,
    lon: float,
    *,
    sleep_sec: float = 2.2,
    commit: bool = True,
) -> Optional[dict[str, str]]:
    lat_k = round(lat, 5)
    lon_k = round(lon, 5)
    row = conn.execute(
        "SELECT display_name, mahalle FROM geocode_cache WHERE lat=? AND lon=?",
        (lat_k, lon_k),
    ).fetchone()
    if row:
        return {"mahalle": row["mahalle"], "acik_adres": row["display_name"]}

    geo = reverse_geocode(lat, lon)
    if geo:
        conn.execute(
            """INSERT OR REPLACE INTO geocode_cache (lat, lon, display_name, mahalle)
               VALUES (?, ?, ?, ?)""",
            (lat_k, lon_k, geo["acik_adres"], geo["mahalle"]),
        )
        if commit:
            conn.commit()
        time.sleep(sleep_sec)
    return geo


def resolve_full_open_address(
    conn,
    tags: dict[str, Any],
    lat: float,
    lon: float,
    *,
    allow_network: bool = True,
) -> tuple[str, str]:
    """
    Tam açık adres üretir (WPF `adres` alanına yazılır).
    Öncelik: Nominatim display_name → OSM addr:* birleşimi.
    """
    geo: Optional[dict[str, str]] = None
    if allow_network and conn is not None:
        geo = reverse_geocode_cached(conn, lat, lon, commit=False)

    if geo and geo.get("acik_adres"):
        acik = geo["acik_adres"]
        if not is_incomplete_open_address(acik):
            return geo["mahalle"][:100], acik[:500]

    acik = format_open_address_from_tags(tags or {})
    suburb = _clean(
        (tags or {}).get("addr:suburb")
        or (tags or {}).get("addr:neighbourhood")
        or (tags or {}).get("addr:district")
        or "Yakutiye"
    )
    return suburb[:100], acik


def build_open_address(
    tags: dict[str, Any],
    lat: float,
    lon: float,
    *,
    geocode: bool = True,
) -> tuple[str, str]:
    """Geriye uyumluluk — conn olmadan kısa yol."""
    if geocode:
        geo = reverse_geocode(lat, lon)
        if geo:
            return geo["mahalle"][:100], geo["acik_adres"][:500]
    acik = format_open_address_from_tags(tags)
    mahalle = _clean(
        tags.get("addr:suburb") or tags.get("addr:neighbourhood") or "Yakutiye"
    )
    return mahalle[:100], acik


def ensure_address_schema(conn) -> None:
    conn.execute(
        """CREATE TABLE IF NOT EXISTS geocode_cache (
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            display_name TEXT NOT NULL,
            mahalle TEXT NOT NULL DEFAULT '',
            PRIMARY KEY (lat, lon)
        )"""
    )
    cols = {r[1] for r in conn.execute("PRAGMA table_info(buildings)").fetchall()}
    if "acik_adres" not in cols:
        conn.execute("ALTER TABLE buildings ADD COLUMN acik_adres TEXT NOT NULL DEFAULT ''")
    layer_cols = {r[1] for r in conn.execute("PRAGMA table_info(building_layers)").fetchall()}
    if "acik_adres" not in layer_cols:
        conn.execute(
            "ALTER TABLE building_layers ADD COLUMN acik_adres TEXT NOT NULL DEFAULT ''"
        )
    conn.commit()
