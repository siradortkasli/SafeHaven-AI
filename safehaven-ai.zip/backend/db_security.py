"""SQLite güvenlik ve bütünlük ayarları."""

import sqlite3


def apply_security_pragmas(conn: sqlite3.Connection) -> None:
    """Veritabanı bağlantısı için güvenli PRAGMA ayarlarını uygular."""
    conn.execute("PRAGMA busy_timeout = 60000")
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA secure_delete = ON")
    conn.execute("PRAGMA temp_store = MEMORY")
    conn.execute("PRAGMA cache_size = -64000")


def open_secure_connection(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, timeout=30.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    apply_security_pragmas(conn)
    return conn
