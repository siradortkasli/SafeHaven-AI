import math
import os

from dotenv import load_dotenv

load_dotenv()

try:
    from openai import OpenAI
except ImportError:  # pragma: no cover
    OpenAI = None  # type: ignore[misc, assignment]

api_key = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=api_key) if (OpenAI and api_key) else None
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")


def _get_value(building, key, default="-"):
    if isinstance(building, dict):
        return building.get(key, default)
    return getattr(building, key, default)


def generate_prompt(building, risk_score, risk_level):
    return f"""
Sen bir belediye afet risk analiz asistanısın.

Aşağıdaki bina verilerini kullanarak kısa, resmi ve anlaşılır bir risk değerlendirmesi üret.

Kurallar:
- Panik yaratma.
- Kesin yıkılır, bina çöker gibi iddialar kullanma.
- "Ön değerlendirme" ifadesini kullan.
- Kişisel veri verme.
- Belediye personeline uygun profesyonel dil kullan.
- En fazla 4 cümle yaz; yalnızca risk özeti ver (yapısal mühendislik detayı ve aksiyon planı yazma).
- Belirleyici 2-3 etkeni adlandır; tekrarlayan genel cümlelerden kaçın.

Bina verileri:
Bina ID: {_get_value(building, "id", "-")}
Mahalle: {_get_value(building, "mahalle")}
Adres: {_get_value(building, "adres")}
Bina yaşı: {_get_value(building, "bina_yasi")}
Kat sayısı: {_get_value(building, "kat_sayisi")}
Zemin riski: {_get_value(building, "zemin_riski")}/5
Hasar durumu: {_get_value(building, "hasar_durumu")}/5
Yaşlı sayısı: {_get_value(building, "yasli_sayisi")}
Engelli sayısı: {_get_value(building, "engelli_sayisi")}
Çocuk sayısı: {_get_value(building, "cocuk_sayisi")}
Risk skoru: {risk_score}
Risk seviyesi: {risk_level}
"""


def fallback_risk_analysis(building, risk_score, risk_level):
    """Geriye uyumluluk: özet metin üreticisine yönlendirir."""
    return generate_building_ai_summary(building, risk_score, risk_level)


def get_evacuation_difficulty(risk_level: str) -> str:
    """Harita risk sınıfına göre tahliye zorluğu."""
    return {
        "Acil Müdahale": "Yüksek",
        "Yüksek Risk": "Yüksek",
        "Orta Risk": "Orta",
        "Düşük Risk": "Düşük",
    }.get(risk_level, "Orta")


def generate_building_ai_summary(building, risk_score, risk_level):
    """Harita risk sınıfı özeti — yapı yaşı/zemin/hasar sayıları burada yer almaz."""
    yasli = int(_get_value(building, "yasli_sayisi", 0))
    engelli = int(_get_value(building, "engelli_sayisi", 0))
    cocuk = int(_get_value(building, "cocuk_sayisi", 0))
    mahalle = _get_value(building, "mahalle", "Erzurum")
    adres = _get_value(building, "adres", "Adres bilgisi yok")
    bina_id = _get_value(building, "id", "-")

    level_action = {
        "Acil Müdahale": (
            "72 saat içinde saha müdahalesi, geçici tahliye değerlendirmesi ve "
            "kırılgan nüfus için öncelikli destek planı gerekir."
        ),
        "Yüksek Risk": (
            "7 gün içinde teknik inceleme ve öncelikli izleme listesine alma önerilir."
        ),
        "Orta Risk": (
            "Periyodik kontrol takvimine alınması ve detaylı yapı raporu istenmesi uygundur."
        ),
        "Düşük Risk": (
            "Rutin yıllık denetim ve standart tahliye planı yeterlidir; acil müdahale gerekmez."
        ),
    }

    tahliye = get_evacuation_difficulty(risk_level)
    vuln = yasli + engelli + cocuk
    if vuln > 0:
        vuln_note = (
            f" Binada {yasli} yaşlı, {engelli} engelli, {cocuk} çocuk kayıtlı; "
            f"tahliye zorluğu haritada '{tahliye}' olarak işaretlenmiştir."
        )
    else:
        vuln_note = f" Tahliye zorluğu harita sınıfına göre '{tahliye}' düzeyindedir."

    return (
        f"[Bina #{bina_id}] {mahalle}, {adres}: Harita risk sınıfı '{risk_level}' "
        f"(normalize skor {risk_score}/100). {level_action.get(risk_level, 'Belediye değerlendirmesi önerilir.')}"
        f"{vuln_note}"
    )


def generate_building_structural_note(building) -> str:
    """Mühendislik inceleme görevleri — risk skoru ve harita sınıfı tekrarlanmaz."""
    bina_yasi = int(_get_value(building, "bina_yasi", 0))
    kat_sayisi = int(_get_value(building, "kat_sayisi", 0))
    zemin_riski = int(_get_value(building, "zemin_riski", 0))
    hasar_durumu = int(_get_value(building, "hasar_durumu", 0))

    tasks: list[str] = []

    if bina_yasi >= 45:
        tasks.append("Beton örnekleme, karbonatlaşma ve donatı korozyonu testi")
    elif bina_yasi >= 30:
        tasks.append("Kolon-kiriş birleşimleri ve betonarme dayanım deneyi")
    elif bina_yasi >= 15:
        tasks.append("Periyodik betonarme görsel muayene ve nem/küf taraması")
    else:
        tasks.append("Taşıyıcı sistem sertlik uyumu ve bağlantı detayı kontrolü")

    if hasar_durumu >= 4:
        tasks.append("Cephe ve taşıyıcı çatlak haritalaması + fotoğraflı hasar envanteri")
    elif hasar_durumu >= 3:
        tasks.append("Yapısal çatlak genişlik ölçümü ve mühendislik raporu")

    if zemin_riski >= 4:
        tasks.append("Jeoteknik sondaj, amplifikasyon ve sıvılaşma analizi")
    elif zemin_riski >= 3:
        tasks.append("Temel oturma ve zemin–yapı etkileşimi izleme noktaları")

    if kat_sayisi >= 7:
        tasks.append("Yumuşak kat / düzensizlik (A/V oranı) hesabı")
    elif kat_sayisi >= 4:
        tasks.append("Kat rijitlik dağılımı ve düzensizlik kontrolü")

    if len(tasks) == 1:
        return f"Önerilen saha mühendisliği incelemeleri: {tasks[0]}."
    return "Önerilen saha mühendisliği incelemeleri: " + "; ".join(tasks) + "."


def generate_building_decision_factors(building, risk_score) -> list[str]:
    """Karar faktörleri — yalnızca madde listesi."""
    bina_yasi = int(_get_value(building, "bina_yasi", 0))
    kat_sayisi = int(_get_value(building, "kat_sayisi", 0))
    zemin_riski = int(_get_value(building, "zemin_riski", 0))
    hasar_durumu = int(_get_value(building, "hasar_durumu", 0))
    yasli = int(_get_value(building, "yasli_sayisi", 0))
    engelli = int(_get_value(building, "engelli_sayisi", 0))
    cocuk = int(_get_value(building, "cocuk_sayisi", 0))

    factors: list[str] = []

    if bina_yasi > 30:
        factors.append(f"Bina yaşı yüksek ({bina_yasi} yıl)")
    elif bina_yasi > 15:
        factors.append(f"Orta bina yaşı ({bina_yasi} yıl)")

    if kat_sayisi >= 5:
        factors.append(f"Yüksek kat sayısı ({kat_sayisi})")

    if zemin_riski >= 4:
        factors.append(f"Zemin riski kritik ({zemin_riski}/5)")
    elif zemin_riski >= 3:
        factors.append(f"Riskli zemin ({zemin_riski}/5)")

    if hasar_durumu >= 4:
        factors.append(f"Ağır hasar kaydı ({hasar_durumu}/5)")
    elif hasar_durumu >= 3:
        factors.append(f"Yapısal hasar izi ({hasar_durumu}/5)")

    if yasli > 0:
        factors.append(f"{yasli} yaşlı sakin")
    if engelli > 0:
        factors.append(f"{engelli} engelli sakin")
    if cocuk > 0:
        factors.append(f"{cocuk} çocuk")

    if risk_score >= 75:
        factors.append("Acil müdahale eşiği")
    elif risk_score >= 50:
        factors.append("Yüksek risk skoru")

    if not factors:
        factors.append("Düşük yapısal risk göstergesi")

    return factors


def generate_ai_analysis(building, risk_score, risk_level):
    """LLM varsa OpenAI ile açıklama üretir; yoksa fallback metin döndürür."""
    try:
        if client is None:
            return fallback_risk_analysis(building, risk_score, risk_level)

        prompt = generate_prompt(building, risk_score, risk_level)
        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt.strip()}],
            max_tokens=320,
            temperature=0.4,
        )
        text = (response.choices[0].message.content or "").strip()
        return text or fallback_risk_analysis(building, risk_score, risk_level)
    except Exception:
        return fallback_risk_analysis(building, risk_score, risk_level)


def generate_action_plan(building, risk_score, risk_level):
    if risk_level == "Acil Müdahale":
        return (
            "72 saat içinde teknik saha incelemesi başlatılmalı, geçici tahliye planı hazırlanmalı, "
            "kira yardımı ve sosyal destek süreçleri değerlendirmeye alınmalıdır."
        )

    if risk_level == "Yüksek Risk":
        return (
            "7 gün içinde yapı güvenliği incelemesi yapılmalı, bina belediyenin öncelikli izleme listesine alınmalı "
            "ve kırılgan nüfus için tahliye destek planı hazırlanmalıdır."
        )

    if risk_level == "Orta Risk":
        return (
            "Bina periyodik kontrol listesine alınmalı, detaylı yapı incelemesi için teknik ekip yönlendirilmelidir."
        )

    return (
        "Bina rutin belediye kontrol takvimine alınabilir. Şu an için acil müdahale önerilmemektedir."
    )


def generate_ethics_check(building, risk_score, risk_level):
    return (
        "Etik denetim sonucu: Karar; bina yaşı, kat sayısı, zemin riski, hasar durumu ve kırılgan nüfus "
        "göstergelerine dayalı olarak üretilmiştir. Kişisel kimlik bilgileri kullanılmamış, yalnızca sayısal ve "
        "anonimleştirilmiş veriler değerlendirilmiştir. Sonuçlar nihai karar değil, belediye ekipleri için "
        "açıklanabilir bir ön değerlendirme çıktısıdır."
    )


def generate_citizen_message(building, risk_level):
    mahalle = _get_value(building, "mahalle", "")
    adres = _get_value(building, "adres", "")

    return (
        f"Sayın vatandaşımız, {mahalle} mahallesinde bulunan {adres} adresindeki binanız, "
        f"belediyemiz tarafından yapılan ön değerlendirme kapsamında '{risk_level}' grubunda değerlendirilmiştir. "
        f"Detaylı inceleme için belediye ekipleri gerekli bilgilendirmeyi yapacaktır."
    )


def calculate_distance_km(lat1, lon1, lat2, lon2):
    try:
        lat1 = math.radians(float(lat1))
        lon1 = math.radians(float(lon1))
        lat2 = math.radians(float(lat2))
        lon2 = math.radians(float(lon2))
    except (TypeError, ValueError):
        return None

    earth_radius_km = 6371
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(earth_radius_km * c, 2)


def recommend_safe_zone_by_location(building, safe_zones):
    building_lat = _get_value(building, "enlem", None)
    building_lon = _get_value(building, "boylam", None)
    engelli_sayisi = int(_get_value(building, "engelli_sayisi", 0))

    if building_lat is None or building_lon is None:
        return None

    suitable_zones = []

    for zone in safe_zones:
        kapasite = int(zone.get("kapasite", 0))
        doluluk = int(zone.get("doluluk", 0))
        bos_kapasite = kapasite - doluluk

        if bos_kapasite <= 0:
            continue

        if engelli_sayisi > 0 and int(zone.get("engelli_uygun", 0)) != 1:
            continue

        zone_lat = zone.get("enlem") or zone.get("lat")
        zone_lon = zone.get("boylam") or zone.get("lon")

        distance = calculate_distance_km(
            building_lat, building_lon, zone_lat, zone_lon
        )

        if distance is None:
            continue

        zone_with_info = dict(zone)
        zone_with_info["uzaklik_km"] = distance
        zone_with_info["bos_kapasite"] = bos_kapasite
        suitable_zones.append(zone_with_info)

    if not suitable_zones:
        return None

    suitable_zones.sort(key=lambda z: z["uzaklik_km"])
    return suitable_zones[0]


def generate_safe_zone_explanation(building, safe_zone):
    if safe_zone is None:
        return (
            "Bu bina için uygun kapasite ve erişilebilirlik şartlarını sağlayan güvenli alan bulunamadı. "
            "Belediye ekiplerinin manuel yönlendirme yapması önerilir."
        )

    engelli_uygun_text = "uygun" if int(safe_zone.get("engelli_uygun", 1)) == 1 else "uygun değil"

    return (
        f"Önerilen güvenli alan '{safe_zone.get('ad')}' olarak belirlenmiştir. "
        f"Bu alan binaya yaklaşık {safe_zone.get('uzaklik_km')} km uzaklıktadır. "
        f"Mevcut boş kapasitesi {safe_zone.get('bos_kapasite')} kişidir. "
        f"Engelli erişimine {engelli_uygun_text} durumdadır. "
        f"Bu öneri; mesafe, kapasite ve kırılgan nüfus ihtiyacı birlikte değerlendirilerek oluşturulmuştur."
    )


def _safe_zone_occupancy_percent(ap: dict, doluluk: int | None = None) -> int:
    kapasite = int(ap.get("kapasite", 0))
    if doluluk is None:
        doluluk = int(ap.get("doluluk", 0))
    if kapasite <= 0:
        return min(100, doluluk)
    return int(min(100, round(doluluk / kapasite * 100)))


def generate_safe_zone_listing_explanation(ap: dict, guvenlik_skoru: float) -> str:
    """Alan tanımı ve kapasite profili — doluluk ayrı alanda."""
    ad = ap.get("ad", "Toplanma alanı")
    ilce = ap.get("ilce", "")
    kapasite = int(ap.get("kapasite", 0))
    alan_m2 = float(ap.get("alan_m2", 0) or 0)
    engelli = int(ap.get("engelli_uygun", 1)) == 1
    ulasim = (ap.get("ulasim_durumu") or "Açık").strip()

    m2_per_person = round(alan_m2 / kapasite, 1) if kapasite > 0 and alan_m2 > 0 else 0.0

    if guvenlik_skoru >= 80:
        rol = "birincil toplanma noktası"
    elif guvenlik_skoru >= 60:
        rol = "bölgesel toplanma alanı"
    else:
        rol = "yedek / tamamlayıcı toplanma alanı"

    engelli_text = "engelli erişimine uygun" if engelli else "engelli erişimi sınırlı"

    return (
        f"'{ad}' ({ilce}): {kapasite:,} kişi kapasiteli, {alan_m2:,.0f} m² "
        f"({m2_per_person} m²/kişi). Güvenlik skoru {guvenlik_skoru}/100 — {rol}. "
        f"Ulaşım: {ulasim}; alan {engelli_text}. "
        f"Afet anında ulaşım ve kapasite yetkililerce doğrulanmalıdır."
    )


def generate_safe_zone_occupancy_note(ap: dict, doluluk: int | None = None) -> str:
    """Yalnızca doluluk değerlendirmesi."""
    ad = ap.get("ad", "Alan")
    kapasite = int(ap.get("kapasite", 0))
    if doluluk is None:
        doluluk = int(ap.get("doluluk", 0))
    percent = _safe_zone_occupancy_percent(ap, doluluk)

    if kapasite <= 0:
        return f"{ad}: Kapasite verisi eksik; doluluk izlenemiyor."

    bos = max(0, kapasite - doluluk)
    if percent >= 80:
        return (
            f"{ad} %{percent} dolu ({doluluk}/{kapasite} kişi). "
            f"Kalan {bos} kişilik kapasite kritik eşikte — alternatif alanlara yönlendirin."
        )
    if percent >= 50:
        return (
            f"{ad} %{percent} dolu ({doluluk}/{kapasite} kişi). "
            f"Kalan {bos} kişi; yoğunluk artıyor, tahliye akışı izlenmeli."
        )
    return (
        f"{ad} %{percent} dolu ({doluluk}/{kapasite} kişi). "
        f"Kalan {bos} kişilik kapasite tahliye yönlendirmesi için uygundur."
    )


def generate_safe_zone_routing_reason(
    ap: dict, guvenlik_skoru: float, doluluk: int | None = None
) -> str:
    """Yönlendirme gerekçesi — alan bazlı dinamik metin."""
    ad = ap.get("ad", "Alan")
    kapasite = int(ap.get("kapasite", 0))
    if doluluk is None:
        doluluk = int(ap.get("doluluk", 0))
    percent = _safe_zone_occupancy_percent(ap, doluluk)
    ulasim = (ap.get("ulasim_durumu") or "Açık").strip().lower()
    engelli = int(ap.get("engelli_uygun", 1)) == 1

    parts: list[str] = []

    if percent >= 80:
        parts.append(f"{ad} doluluk açısından kritik (%{percent})")
    elif percent >= 50:
        parts.append(f"{ad} için kontrollü yönlendirme uygun (%{percent} doluluk)")
    elif guvenlik_skoru >= 75:
        parts.append(f"{ad} yüksek güvenlik skoru ({guvenlik_skoru}) ve düşük doluluk nedeniyle öncelikli")
    else:
        parts.append(f"{ad} mevcut kapasite ile standart yönlendirme alanı")

    if "kapalı" in ulasim or "kapali" in ulasim:
        parts.append("ulaşım yolu şu an kapalı görünüyor — saha doğrulaması gerekli")
    elif "açık" in ulasim or "acik" in ulasim or "uygun" in ulasim:
        parts.append("ulaşım yolu açık")

    if engelli:
        parts.append("engelli erişimi mevcut")
    else:
        parts.append("engelli erişimi sınırlı — kırılgan nüfus için alternatif değerlendirin")

    return "; ".join(parts) + "."


def generate_safe_zone_message(building, safe_zone):
    if safe_zone is None:
        return (
            "Sayın vatandaşımız, güvenli alan yönlendirmesi için belediye ekiplerinin duyurularını takip ediniz."
        )

    adres = (
        safe_zone.get("adres")
        or safe_zone.get("ilce")
        or "Adres bilgisi bulunmuyor"
    )

    return (
        f"Sayın vatandaşımız, ön değerlendirme kapsamında size en uygun toplanma alanı "
        f"'{safe_zone.get('ad')}' olarak belirlenmiştir. "
        f"Konum bilgisi: {adres}. "
        f"Lütfen belediye ekiplerinin yönlendirmelerine uyunuz."
    )


def generate_priority_reason(building, risk_score, risk_level, safe_zone=None):
    yasli = _get_value(building, "yasli_sayisi", 0)
    engelli = _get_value(building, "engelli_sayisi", 0)
    cocuk = _get_value(building, "cocuk_sayisi", 0)
    zemin = _get_value(building, "zemin_riski", 0)
    hasar = _get_value(building, "hasar_durumu", 0)

    text = (
        f"Bu bina '{risk_level}' öncelik grubuna alınmıştır. "
        f"Kararda zemin riski ({zemin}/5), hasar durumu ({hasar}/5), "
        f"risk skoru ({risk_score}) ve kırılgan nüfus "
        f"({yasli} yaşlı, {engelli} engelli, {cocuk} çocuk) dikkate alınmıştır."
    )

    if safe_zone:
        text += (
            f" En uygun güvenli alan olarak '{safe_zone.get('ad')}' önerilmiştir. "
            f"Bu seçim mesafe, boş kapasite ve erişilebilirlik kriterlerine göre yapılmıştır."
        )

    return text


def generate_capacity_warning(safe_zone):
    if safe_zone is None:
        return "Kapasite analizi yapılamadı."

    kapasite = int(safe_zone.get("kapasite", 0))
    doluluk = int(safe_zone.get("doluluk", 0))

    if kapasite <= 0:
        return "Kapasite bilgisi bulunamadı."

    doluluk_orani = doluluk / kapasite

    if doluluk_orani >= 0.9:
        return (
            "UYARI: Bu güvenli alan kapasite sınırına çok yakındır. "
            "Alternatif tahliye alanları değerlendirilmelidir."
        )

    if doluluk_orani >= 0.7:
        return "DİKKAT: Güvenli alan yoğunluk seviyesine yaklaşmaktadır."

    return "Güvenli alan kapasitesi yeterli seviyededir."


def generate_full_report(building, risk_score, risk_level, safe_zones=None):
    analysis = generate_ai_analysis(building, risk_score, risk_level)
    action_plan = generate_action_plan(building, risk_score, risk_level)
    ethics_check = generate_ethics_check(building, risk_score, risk_level)
    citizen_message = generate_citizen_message(building, risk_level)

    selected_safe_zone = None
    safe_zone_explanation = "Güvenli alan verisi bulunmadığı için yönlendirme yapılmadı."
    safe_zone_message = "Güvenli alan yönlendirmesi için belediye duyurularını takip ediniz."

    if safe_zones:
        selected_safe_zone = recommend_safe_zone_by_location(building, safe_zones)
        safe_zone_explanation = generate_safe_zone_explanation(building, selected_safe_zone)
        safe_zone_message = generate_safe_zone_message(building, selected_safe_zone)

    priority_reason = generate_priority_reason(
        building, risk_score, risk_level, selected_safe_zone
    )
    capacity_warning = generate_capacity_warning(selected_safe_zone)

    return {
        "risk_score": risk_score,
        "risk_level": risk_level,
        "ai_analysis": analysis,
        "action_plan": action_plan,
        "ethics_check": ethics_check,
        "citizen_message": citizen_message,
        "selected_safe_zone": selected_safe_zone,
        "safe_zone_explanation": safe_zone_explanation,
        "safe_zone_message": safe_zone_message,
        "priority_reason": priority_reason,
        "capacity_warning": capacity_warning,
    }


def _get_magnitude(eq) -> float:
    try:
        return float(
            eq.get("magnitude")
            or eq.get("buyukluk")
            or eq.get("mag")
            or 0
        )
    except (TypeError, ValueError):
        return 0.0


def generate_earthquake_ai_summary(earthquakes, city_name="Erzurum"):
    if not earthquakes:
        return (
            f"{city_name} ve çevresi için güncel deprem verisi bulunamadı. "
            "Belediye ekiplerinin resmi kaynakları izlemeye devam etmesi önerilir."
        )

    total_count = len(earthquakes)
    max_eq = max(earthquakes, key=_get_magnitude)
    max_magnitude = _get_magnitude(max_eq)
    max_location = (
        max_eq.get("location")
        or max_eq.get("yer")
        or max_eq.get("place")
        or "Bilinmeyen bölge"
    )

    risky_count = sum(1 for eq in earthquakes if _get_magnitude(eq) >= 3.5)

    if risky_count >= 3:
        activity_level = "Yüksek"
        recommendation = (
            "yüksek riskli binaların öncelikli kontrol listesine alınması, "
            "güvenli alan kapasite durumlarının gözden geçirilmesi ve saha ekiplerinin hazır bekletilmesi"
        )
    elif risky_count >= 1:
        activity_level = "Orta"
        recommendation = (
            "riskli bina listesinin güncellenmesi ve kritik bölgelerde ön inceleme yapılması"
        )
    else:
        activity_level = "Düşük"
        recommendation = "rutin izleme sürecinin devam ettirilmesi"

    return (
        f"Son deprem verilerine göre {city_name} ve çevresinde {total_count} deprem kaydı incelenmiştir. "
        f"En yüksek büyüklük {max_magnitude} olarak {max_location} bölgesinde kaydedilmiştir. "
        f"3.5 ve üzeri deprem sayısı {risky_count} olarak belirlenmiştir. "
        f"Deprem aktivite seviyesi '{activity_level}' olarak değerlendirilmiştir. "
        f"Belediye için öneri: {recommendation}."
    )


def generate_city_ai_summary(buildings, safe_zones=None, earthquakes=None, city_name="Erzurum"):
    safe_zones = safe_zones or []
    earthquakes = earthquakes or []

    total_buildings = len(buildings)
    high_risk_count = 0
    emergency_count = 0
    vulnerable_population = 0

    for building in buildings:
        risk_level = (
            building.get("risk_level")
            or building.get("risk_seviyesi")
            or ""
        )

        if risk_level == "Yüksek Risk":
            high_risk_count += 1
        if risk_level == "Acil Müdahale":
            emergency_count += 1

        vulnerable_population += int(building.get("yasli_sayisi", 0))
        vulnerable_population += int(building.get("engelli_sayisi", 0))
        vulnerable_population += int(building.get("cocuk_sayisi", 0))

    critical_safe_zone_count = 0
    for zone in safe_zones:
        kapasite = int(zone.get("kapasite", 0))
        doluluk = int(zone.get("doluluk", 0))
        if kapasite > 0 and doluluk / kapasite >= 0.7:
            critical_safe_zone_count += 1

    earthquake_over_35 = sum(1 for eq in earthquakes if _get_magnitude(eq) >= 3.5)
    max_magnitude = max((_get_magnitude(eq) for eq in earthquakes), default=0)

    if earthquake_over_35 >= 3:
        earthquake_activity = "Yüksek"
    elif earthquake_over_35 >= 1:
        earthquake_activity = "Orta"
    else:
        earthquake_activity = "Düşük"

    if emergency_count > 0:
        general_status = "Kritik İzleme"
    elif high_risk_count > 0 or earthquake_activity == "Orta":
        general_status = "Dikkat Gerektiriyor"
    else:
        general_status = "Normal İzleme"

    summary_text = (
        f"{city_name} genelinde {total_buildings} bina verisi incelenmiştir. "
        f"{emergency_count} bina acil müdahale, {high_risk_count} bina yüksek risk grubundadır. "
        f"Toplam {vulnerable_population} kırılgan birey risk değerlendirmesine dahil edilmiştir. "
        f"{critical_safe_zone_count} güvenli alan kapasite açısından dikkat seviyesine yaklaşmaktadır. "
        f"Son deprem verilerine göre aktivite seviyesi '{earthquake_activity}' olarak değerlendirilmiştir. "
        f"Genel belediye afet durumu: {general_status}."
    )

    recommendation = (
        "Acil müdahale grubundaki binalar öncelikli saha kontrolüne alınmalı, "
        "güvenli alan kapasite durumları izlenmeli ve kırılgan nüfus bulunan yapılar için tahliye planı güncellenmelidir."
    )

    return {
        "city": city_name,
        "general_status": general_status,
        "total_buildings": total_buildings,
        "emergency_buildings": emergency_count,
        "high_risk_buildings": high_risk_count,
        "vulnerable_population": vulnerable_population,
        "critical_safe_zones": critical_safe_zone_count,
        "earthquake_count": len(earthquakes),
        "earthquake_activity": earthquake_activity,
        "max_magnitude": max_magnitude,
        "summary_text": summary_text,
        "recommendation": recommendation,
    }
