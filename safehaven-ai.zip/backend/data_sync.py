"""
Erzurum verilerini harici API'lerden senkronize eder.
Sahte seed bina kayıtlarını temizleyip OSM + Kandilli verisiyle doldurur.
"""

from __future__ import annotations

import json
import random
import sqlite3
import urllib.parse
import urllib.request
from datetime import datetime
from typing import Any, Optional

from address_utils import (
    ensure_address_schema,
    format_open_address_from_tags,
    is_incomplete_open_address,
    resolve_full_open_address,
)
from db_security import apply_security_pragmas
from erzurum_geo import (
    ERZURUM_BBOX_OVERPASS,
    erzurum_sql_where,
    is_deprem_risk_building,
    is_in_erzurum_bbox,
)
from tradres_client import enrich_open_address

OVERPASS_URL = "https://overpass-api.de/api/interpreter"
ERZURUM_BBOX = ERZURUM_BBOX_OVERPASS
KANDILLI_BASE = "https://api.orhanaydogdu.com.tr/deprem"
KANDILLI_HEADERS = {"User-Agent": "SafeHaven-AI/3.0", "Accept": "application/json"}

# Erzurum yakını depremler (yaklaşık bbox)
ERZURUM_EQ_LAT = (39.5, 40.5)
ERZURUM_EQ_LON = (40.8, 42.0)


def _kandilli_get(path: str, params: dict) -> dict:
    qs = urllib.parse.urlencode(params)
    url = f"{KANDILLI_BASE}{path}?{qs}"
    req = urllib.request.Request(url, headers=KANDILLI_HEADERS)
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read())


def _kandilli_to_eq(item: dict) -> dict:
    coords = item.get("geojson", {}).get("coordinates", [0.0, 0.0])
    lon, lat = float(coords[0]), float(coords[1])
    dt_str = item.get("date_time", "")[:16]
    return {
        "earthquake_id": item.get("earthquake_id", ""),
        "tarih": dt_str,
        "yer": item.get("title", ""),
        "buyukluk": float(item.get("mag", 0)),
        "derinlik": float(item.get("depth", 0)),
        "enlem": lat,
        "boylam": lon,
    }


def _is_in_erzurum_region(lat: float, lon: float) -> bool:
    return is_in_erzurum_bbox(lat, lon)


def purge_non_risk_buildings(conn: sqlite3.Connection) -> int:
    """Camii, garaj vb. deprem riski dışı yapıları buildings tablosundan siler."""
    removed = 0
    rows = conn.execute(
        """SELECT b.id, l.raw_tags
           FROM buildings b
           LEFT JOIN building_layers l ON l.osm_id = b.osm_id"""
    ).fetchall()

    for row in rows:
        try:
            tags = json.loads(row["raw_tags"] or "{}")
        except json.JSONDecodeError:
            tags = {}
        if is_deprem_risk_building(tags):
            continue
        bid = row["id"]
        conn.execute("DELETE FROM risk_history WHERE building_id = ?", (bid,))
        conn.execute("DELETE FROM residents WHERE building_id = ?", (bid,))
        conn.execute("DELETE FROM buildings WHERE id = ?", (bid,))
        removed += 1

    conn.commit()
    return removed


def purge_buildings_outside_erzurum(conn: sqlite3.Connection) -> int:
    """Erzurum bbox dışındaki bina ve katman kayıtlarını siler."""
    removed = 0
    for row in conn.execute("SELECT id, enlem, boylam FROM buildings").fetchall():
        if not is_in_erzurum_bbox(row["enlem"], row["boylam"]):
            bid = row["id"]
            conn.execute("DELETE FROM risk_history WHERE building_id = ?", (bid,))
            conn.execute("DELETE FROM residents WHERE building_id = ?", (bid,))
            conn.execute("DELETE FROM buildings WHERE id = ?", (bid,))
            removed += 1

    conn.execute(
        """DELETE FROM building_layers
           WHERE lat < ? OR lat > ? OR lon < ? OR lon > ?""",
        (
            39.72,
            39.98,
            41.05,
            41.55,
        ),
    )
    conn.commit()
    return removed


def _extract_osm_building(element: dict, *, geocode: bool = False) -> Optional[dict]:
    center = element.get("center")
    if not center:
        return None
    tags = element.get("tags", {})
    lat, lon = center["lat"], center["lon"]

    if not is_in_erzurum_bbox(lat, lon):
        return None
    if not is_deprem_risk_building(tags):
        return None
    acik_adres = format_open_address_from_tags(tags)
    mahalle = (
        tags.get("addr:suburb")
        or tags.get("addr:neighbourhood")
        or tags.get("addr:district")
        or "Yakutiye"
    )
    mahalle = " ".join(str(mahalle).split())[:100]

    kat_str = tags.get("building:levels", "1")
    try:
        kat_sayisi = max(1, int(float(kat_str)))
    except (ValueError, TypeError):
        kat_sayisi = 1

    start_date = tags.get("start_date", "")
    bina_yasi = 0
    if start_date and len(start_date) >= 4 and start_date[:4].isdigit():
        bina_yasi = max(0, datetime.now().year - int(start_date[:4]))

    return {
        "osm_id": str(element["id"]),
        "adres": acik_adres[:500],
        "acik_adres": acik_adres[:500],
        "mahalle": mahalle[:100],
        "kat_sayisi": kat_sayisi,
        "bina_yasi": bina_yasi,
        "lat": lat,
        "lon": lon,
        "raw_tags": json.dumps(tags, ensure_ascii=False)[:2000],
    }


def _estimate_risk_fields(layer: dict) -> dict:
    """OSM verisinden risk alanlarını türetir — haritada yeşil/turuncu/kırmızı dağılımı için."""
    rng = random.Random(hash(str(layer.get("osm_id", ""))) % (2**32))
    tags: dict = {}
    raw = layer.get("raw_tags")
    if raw:
        try:
            tags = json.loads(raw) if isinstance(raw, str) else raw
        except json.JSONDecodeError:
            tags = {}

    kat = max(1, int(layer.get("kat_sayisi") or 1))
    yas = max(0, int(layer.get("bina_yasi") or 0))
    btype = (tags.get("building") or "yes").lower()

    if btype in ("school", "university", "hospital", "dormitory"):
        kat = max(kat, 4)
    elif btype in ("apartments", "apartment", "commercial", "office"):
        kat = max(kat, 3)

    zemin = min(5, 2 + kat // 2 + yas // 20 + rng.randint(0, 2))
    hasar = min(5, 1 + yas // 8 + kat // 3 + rng.randint(0, 2))
    yasli = min(20, rng.randint(1, 12) + kat * 2)
    engelli = min(10, rng.randint(0, 6) + kat)
    cocuk = min(25, rng.randint(2, 16) + kat * 2)

    return {
        "zemin_riski": zemin,
        "hasar_durumu": hasar,
        "yasli_sayisi": yasli,
        "engelli_sayisi": engelli,
        "cocuk_sayisi": cocuk,
    }


def recalibrate_building_risks(conn: sqlite3.Connection) -> int:
    """Mevcut binaların risk alanlarını OSM verisine göre yeniden hesaplar."""
    updated = 0
    layer_rows = {
        r["osm_id"]: dict(r)
        for r in conn.execute("SELECT osm_id, raw_tags, kat_sayisi, bina_yasi FROM building_layers").fetchall()
    }
    for row in conn.execute(
        "SELECT id, osm_id, kat_sayisi, bina_yasi FROM buildings"
    ).fetchall():
        b = dict(row)
        layer = layer_rows.get(b["osm_id"], {})
        payload = {
            "osm_id": b["osm_id"],
            "kat_sayisi": b["kat_sayisi"],
            "bina_yasi": b["bina_yasi"],
            "raw_tags": layer.get("raw_tags", "{}"),
        }
        risk = _estimate_risk_fields(payload)
        conn.execute(
            """UPDATE buildings
               SET zemin_riski=?, hasar_durumu=?, yasli_sayisi=?,
                   engelli_sayisi=?, cocuk_sayisi=?
               WHERE id=?""",
            (
                risk["zemin_riski"],
                risk["hasar_durumu"],
                risk["yasli_sayisi"],
                risk["engelli_sayisi"],
                risk["cocuk_sayisi"],
                b["id"],
            ),
        )
        updated += 1
    conn.commit()
    return updated


def purge_fake_buildings(conn: sqlite3.Connection) -> int:
    """Sahte / OSM kaynağı olmayan bina kayıtlarını siler."""
    fake_ids = [
        r[0]
        for r in conn.execute(
            "SELECT id FROM buildings WHERE osm_id IS NULL OR TRIM(osm_id) = ''"
        ).fetchall()
    ]
    if not fake_ids:
        return 0

    placeholders = ",".join("?" * len(fake_ids))
    conn.execute(
        f"DELETE FROM risk_history WHERE building_id IN ({placeholders})",
        fake_ids,
    )
    conn.execute(
        f"DELETE FROM residents WHERE building_id IN ({placeholders})",
        fake_ids,
    )
    cur = conn.execute(
        f"DELETE FROM buildings WHERE id IN ({placeholders})",
        fake_ids,
    )
    conn.commit()
    return cur.rowcount


def sync_osm_layers(conn: sqlite3.Connection, limit: int = 150) -> dict[str, int]:
    ensure_address_schema(conn)
    query = f"""[out:json][timeout:60];
(
  way["building"~"^(yes|residential|apartments|apartment|house|detached|terrace|dormitory|school|university|hospital|commercial|retail|office|public|civic|hotel|industrial)$"]({ERZURUM_BBOX});
);
out center tags {limit};
"""
    payload = urllib.parse.urlencode({"data": query}).encode()
    req = urllib.request.Request(
        OVERPASS_URL,
        data=payload,
        headers={
            "User-Agent": "SafeHaven-AI/3.0",
            "Content-Type": "application/x-www-form-urlencoded",
        },
    )
    with urllib.request.urlopen(req, timeout=70) as resp:
        osm_data = json.loads(resp.read())

    now_ts = datetime.now().isoformat(timespec="seconds")
    added = updated = skipped = 0

    for el in osm_data.get("elements", []):
        b = _extract_osm_building(el)
        if not b:
            skipped += 1
            continue
        existing = conn.execute(
            "SELECT id FROM building_layers WHERE osm_id = ?", (b["osm_id"],)
        ).fetchone()
        if existing:
            conn.execute(
                """UPDATE building_layers
                   SET adres=?, acik_adres=?, mahalle=?, kat_sayisi=?, bina_yasi=?, lat=?, lon=?, raw_tags=?, synced_at=?
                   WHERE osm_id=?""",
                (
                    b["adres"],
                    b["acik_adres"],
                    b["mahalle"],
                    b["kat_sayisi"],
                    b["bina_yasi"],
                    b["lat"],
                    b["lon"],
                    b["raw_tags"],
                    now_ts,
                    b["osm_id"],
                ),
            )
            updated += 1
        else:
            conn.execute(
                """INSERT INTO building_layers
                   (osm_id, adres, acik_adres, mahalle, kat_sayisi, bina_yasi, lat, lon, raw_tags, synced_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    b["osm_id"],
                    b["adres"],
                    b["acik_adres"],
                    b["mahalle"],
                    b["kat_sayisi"],
                    b["bina_yasi"],
                    b["lat"],
                    b["lon"],
                    b["raw_tags"],
                    now_ts,
                ),
            )
            added += 1

    conn.commit()
    return {"eklenen": added, "guncellenen": updated, "atlanan": skipped}


def refresh_building_addresses(
    conn: sqlite3.Connection,
    *,
    max_geocode: int = 250,
) -> dict[str, int]:
    """
    Tüm binaların adresini Nominatim tam açık adres (display_name) ile günceller.
    Eksik adresler önce işlenir.
    """
    ensure_address_schema(conn)
    updated = geocoded = 0

    rows = conn.execute(
        """SELECT b.id, b.osm_id, b.enlem, b.boylam, b.mahalle, b.adres, b.acik_adres,
                  l.raw_tags
           FROM buildings b
           LEFT JOIN building_layers l ON l.osm_id = b.osm_id"""
    ).fetchall()

    def sort_key(row: sqlite3.Row) -> tuple[int, int]:
        cur = (row["acik_adres"] or row["adres"] or "").strip()
        return (0 if is_incomplete_open_address(cur) else 1, int(row["id"]))

    sorted_rows = sorted(rows, key=sort_key)

    for row in sorted_rows:
        b = dict(row)
        tags: dict = {}
        if b.get("raw_tags"):
            try:
                tags = json.loads(b["raw_tags"])
            except json.JSONDecodeError:
                tags = {}

        lat = float(b["enlem"] or 0)
        lon = float(b["boylam"] or 0)
        use_network = geocoded < max_geocode

        prev = (b.get("acik_adres") or b.get("adres") or "").strip()
        mahalle, acik = resolve_full_open_address(
            conn, tags, lat, lon, allow_network=use_network
        )
        if use_network:
            geocoded += 1
        if is_incomplete_open_address(acik) and prev and not is_incomplete_open_address(prev):
            mahalle = (b.get("mahalle") or mahalle)[:100]
            acik = prev
        elif is_incomplete_open_address(acik):
            mahalle, acik = enrich_open_address(tags, lat, lon, acik)

        conn.execute(
            """UPDATE buildings
               SET mahalle=?, adres=?, acik_adres=?
               WHERE id=?""",
            (mahalle, acik, acik, b["id"]),
        )
        if b.get("osm_id"):
            conn.execute(
                """UPDATE building_layers
                   SET mahalle=?, adres=?, acik_adres=?
                   WHERE osm_id=?""",
                (mahalle, acik, acik, b["osm_id"]),
            )
        updated += 1

    try:
        conn.commit()
    except sqlite3.OperationalError:
        import time
        time.sleep(2)
        conn.commit()
    return {"guncellenen": updated, "geocode_ile": geocoded}


def materialize_buildings(conn: sqlite3.Connection, limit: int = 150) -> int:
    """building_layers → buildings tablosuna aktarır."""
    ensure_address_schema(conn)
    purge_fake_buildings(conn)
    layers = conn.execute(
        "SELECT * FROM building_layers ORDER BY synced_at DESC LIMIT ?", (limit,)
    ).fetchall()

    count = 0
    for row in layers:
        layer = dict(row)
        osm_id = layer["osm_id"]
        exists = conn.execute(
            "SELECT id FROM buildings WHERE osm_id = ?", (osm_id,)
        ).fetchone()
        risk = _estimate_risk_fields(layer)
        if exists:
            acik = layer.get("acik_adres") or layer["adres"]
            conn.execute(
                """UPDATE buildings SET
                   mahalle=?, adres=?, acik_adres=?, bina_yasi=?, kat_sayisi=?,
                   zemin_riski=?, hasar_durumu=?, yasli_sayisi=?, engelli_sayisi=?, cocuk_sayisi=?,
                   enlem=?, boylam=?
                   WHERE osm_id=?""",
                (
                    layer["mahalle"],
                    acik,
                    acik,
                    layer["bina_yasi"],
                    layer["kat_sayisi"],
                    risk["zemin_riski"],
                    risk["hasar_durumu"],
                    risk["yasli_sayisi"],
                    risk["engelli_sayisi"],
                    risk["cocuk_sayisi"],
                    layer["lat"],
                    layer["lon"],
                    osm_id,
                ),
            )
        else:
            acik = layer.get("acik_adres") or layer["adres"]
            conn.execute(
                """INSERT INTO buildings
                   (mahalle, adres, acik_adres, bina_yasi, kat_sayisi, zemin_riski, hasar_durumu,
                    yasli_sayisi, engelli_sayisi, cocuk_sayisi, enlem, boylam, osm_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    layer["mahalle"],
                    acik,
                    acik,
                    layer["bina_yasi"],
                    layer["kat_sayisi"],
                    risk["zemin_riski"],
                    risk["hasar_durumu"],
                    risk["yasli_sayisi"],
                    risk["engelli_sayisi"],
                    risk["cocuk_sayisi"],
                    layer["lat"],
                    layer["lon"],
                    osm_id,
                ),
            )
        count += 1

    conn.commit()
    return count


def sync_earthquakes(conn: sqlite3.Connection, limit: int = 50) -> dict[str, int]:
    data = _kandilli_get("/kandilli/live", {"limit": limit, "skip": 0})
    if not data.get("status"):
        return {"eklenen": 0, "atlanan": 0, "hata": 1}

    cols = [r[1] for r in conn.execute("PRAGMA table_info(earthquakes)").fetchall()]
    if "earthquake_id" not in cols:
        conn.execute("ALTER TABLE earthquakes ADD COLUMN earthquake_id TEXT DEFAULT NULL")

    added = skipped = 0
    for item in data.get("result", []):
        eq = _kandilli_to_eq(item)

        eq_id = eq["earthquake_id"]
        if eq_id and conn.execute(
            "SELECT id FROM earthquakes WHERE earthquake_id = ?", (eq_id,)
        ).fetchone():
            skipped += 1
            continue

        conn.execute(
            """INSERT INTO earthquakes
               (tarih, yer, buyukluk, derinlik, enlem, boylam, earthquake_id)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                eq["tarih"],
                eq["yer"],
                eq["buyukluk"],
                eq["derinlik"],
                eq["enlem"],
                eq["boylam"],
                eq_id or None,
            ),
        )
        added += 1

    conn.commit()
    return {"eklenen": added, "atlanan": skipped}


def bootstrap_erzurum_data(conn: sqlite3.Connection, *, force: bool = False) -> dict[str, Any]:
    """Tüm harici veri kaynaklarından Erzurum verisini senkronize eder."""
    apply_security_pragmas(conn)

    building_count = conn.execute("SELECT COUNT(*) FROM buildings").fetchone()[0]
    osm_count = conn.execute(
        "SELECT COUNT(*) FROM buildings WHERE osm_id IS NOT NULL"
    ).fetchone()[0]
    eq_count = conn.execute("SELECT COUNT(*) FROM earthquakes").fetchone()[0]

    non_erzurum = conn.execute(
        f"SELECT COUNT(*) FROM buildings WHERE NOT ({erzurum_sql_where()})"
    ).fetchone()[0]
    needs_buildings = (
        force or building_count == 0 or osm_count < 10 or non_erzurum > 0
    )
    needs_earthquakes = force or eq_count < 30

    result: dict[str, Any] = {
        "buildings_synced": False,
        "earthquakes_synced": False,
        "silinen_sahte_bina": 0,
    }

    ensure_address_schema(conn)

    missing_acik = conn.execute(
        """SELECT COUNT(*) FROM buildings
           WHERE acik_adres IS NULL OR TRIM(acik_adres) = ''
              OR adres = 'Adres bilgisi yok' OR mahalle = 'Erzurum'"""
    ).fetchone()[0]

    result["erzurum_disinda_silinen"] = purge_buildings_outside_erzurum(conn)
    result["risk_disi_silinen"] = purge_non_risk_buildings(conn)

    if needs_buildings:
        result["silinen_sahte_bina"] = purge_fake_buildings(conn)
        try:
            result["osm"] = sync_osm_layers(conn, limit=200)
            result["bina_aktarilan"] = materialize_buildings(conn, limit=200)
            result["risk_guncellenen"] = recalibrate_building_risks(conn)
            result["adres"] = refresh_building_addresses(conn, max_geocode=250)
            result["erzurum_disinda_silinen"] += purge_buildings_outside_erzurum(conn)
            result["risk_disi_silinen"] = purge_non_risk_buildings(conn)
            result["buildings_synced"] = True
        except Exception as exc:
            result["osm_hata"] = str(exc)
    else:
        short_addr = sum(
            1
            for r in conn.execute("SELECT adres, acik_adres FROM buildings").fetchall()
            if is_incomplete_open_address((r["acik_adres"] or r["adres"] or "").strip())
        )
        if short_addr > 0 or missing_acik > 0:
            try:
                result["adres"] = refresh_building_addresses(conn, max_geocode=250)
            except Exception as exc:
                result["adres_hata"] = str(exc)
        try:
            result["risk_guncellenen"] = recalibrate_building_risks(conn)
        except Exception as exc:
            result["risk_hata"] = str(exc)

    if needs_earthquakes:
        try:
            result["deprem"] = sync_earthquakes(conn, limit=100)
            result["earthquakes_synced"] = True
        except Exception as exc:
            result["deprem_hata"] = str(exc)

    result["toplam_bina"] = conn.execute("SELECT COUNT(*) FROM buildings").fetchone()[0]
    result["toplam_deprem"] = conn.execute("SELECT COUNT(*) FROM earthquakes").fetchone()[0]
    result["synced_at"] = datetime.now().isoformat(timespec="seconds")
    return result
