"""
main.py  –  SafeHaven AI  v2
-----------------------------
Deprem riski binaları önceliklendirme backend.

Başlatmak için:
    uvicorn main:app --reload
Swagger UI:
    http://127.0.0.1:8000/docs

YENİLİKLER (v1 → v2):
  1. Normalize risk skoru (0-100 arası, gerçekçi skor)
  2. Kategori bazlı ağırlıklar (yapısal / zemin / sosyal)
  3. risk_breakdown – her faktörün % katkısı
  4. POST /analyze/{id} → risk_history tablosuna kayıt yazar
  5. GET  /buildings/{id}/history → zaman içindeki risk değişimi
  6. GET  /analyze/{id} içinde mahalle benchmark karşılaştırması
  7. GET  /neighborhood-stats → mahalle bazlı sıralama
  8. GET  /buildings  → ?mahalle / ?risk_level / ?min_score filtreleri
  9. POST /buildings  → yeni bina ekleme
"""

import json
import math
import os
import sqlite3
import urllib.parse
import urllib.request

import requests
from contextlib import contextmanager
from datetime import datetime
from dotenv import load_dotenv
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, Query
from db_security import apply_security_pragmas
from data_sync import (
    bootstrap_erzurum_data,
    purge_buildings_outside_erzurum,
    purge_non_risk_buildings,
    recalibrate_building_risks,
    refresh_building_addresses,
    sync_earthquakes,
)
from address_utils import ensure_address_schema
from erzurum_geo import (
    ERZURUM_BBOX_OVERPASS,
    ERZURUM_IL_ADI,
    erzurum_sql_where,
    is_deprem_risk_building,
    is_in_erzurum_bbox,
)
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


load_dotenv()

from ai_agent import (
    fallback_risk_analysis,
    generate_action_plan,
    generate_ai_analysis,
    generate_building_ai_summary,
    generate_building_decision_factors,
    generate_building_structural_note,
    get_evacuation_difficulty,
    generate_city_ai_summary,
    generate_earthquake_ai_summary,
    generate_full_report,
    generate_safe_zone_listing_explanation,
    generate_safe_zone_occupancy_note,
    generate_safe_zone_routing_reason,
)

# ---------------------------------------------------------------------------
# Uygulama
# ---------------------------------------------------------------------------
app = FastAPI(
    title="SafeHaven AI",
    description="Belediyeler için deprem riski binaları önceliklendirme API'si — v2",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.getenv("SAFEHAVEN_DB_PATH", os.path.join(_BACKEND_DIR, "database.db"))

# ---------------------------------------------------------------------------
# Veritabanı yardımcısı
# ---------------------------------------------------------------------------

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    apply_security_pragmas(conn)
    try:
        yield conn
    finally:
        conn.close()


def row_to_dict(row: sqlite3.Row) -> dict:
    return dict(row)


# ---------------------------------------------------------------------------
# YENİLİK 1 & 2 – Normalize + Kategori bazlı ağırlıklar
# ---------------------------------------------------------------------------
#
# Kategoriler:
#   YAPISAL  → bina_yasi, kat_sayisi         (fiziksel dayanıklılık)
#   ZEMİN    → zemin_riski, hasar_durumu     (afet tehlikesi)
#   SOSYAL   → yasli_sayisi, engelli_sayisi, cocuk_sayisi  (korunmasız nüfus)
#
# Ağırlıklar toplamı 100 olacak şekilde kategorilere bölündü:
#   Yapısal  %25  → bina_yasi × 0.25,  kat_sayisi × 4
#   Zemin    %50  → zemin_riski × 15,  hasar_durumu × 20
#   Sosyal   %25  → yasli_sayisi × 3,  engelli_sayisi × 5,  cocuk_sayisi × 2

WEIGHTS: dict[str, float] = {
    "bina_yasi":      0.25,
    "kat_sayisi":     4.0,
    "zemin_riski":    15.0,
    "hasar_durumu":   20.0,
    "yasli_sayisi":   3.0,
    "engelli_sayisi": 5.0,
    "cocuk_sayisi":   2.0,
}

CATEGORIES: dict[str, list[str]] = {
    "yapisal": ["bina_yasi", "kat_sayisi"],
    "zemin":   ["zemin_riski", "hasar_durumu"],
    "sosyal":  ["yasli_sayisi", "engelli_sayisi", "cocuk_sayisi"],
}

FACTOR_LABELS: dict[str, str] = {
    "bina_yasi":      "Yüksek bina yaşı",
    "kat_sayisi":     "Fazla kat sayısı",
    "zemin_riski":    "Zayıf zemin riski",
    "hasar_durumu":   "Yüksek hasar durumu",
    "yasli_sayisi":   "Yaşlı nüfus yoğunluğu",
    "engelli_sayisi": "Engelli nüfus yoğunluğu",
    "cocuk_sayisi":   "Yoğun çocuk nüfusu",
}

# Teorik maksimum – normalize tavanı (en kötü mümkün bina)
# bina_yasi=55, kat=10, zemin=5, hasar=5, yasli=20, engelli=10, cocuk=25
_RAW_MAX: float = (
    55 * 0.25 + 10 * 4.0 + 5 * 15.0 +
    5 * 20.0  + 20 * 3.0 + 10 * 5.0 + 25 * 2.0
)  # ≈ 328.75


def calculate_raw_score(building: dict) -> float:
    """Ham risk skoru (ağırlıklı toplam, üst sınırsız)."""
    return round(sum(building[f] * w for f, w in WEIGHTS.items()), 2)


def normalize_score(raw: float) -> float:
    """Ham skoru 0–100 aralığına normalize eder."""
    return round(min(max(raw / _RAW_MAX * 100, 0.0), 100.0), 2)


def get_risk_level(normalized: float) -> str:
    """0-100 normalize skora göre seviye döndürür."""
    if normalized < 25:   return "Düşük Risk"
    elif normalized < 50: return "Orta Risk"
    elif normalized < 75: return "Yüksek Risk"
    else:                 return "Acil Müdahale"


def get_top_factors(building: dict, n: int = 3) -> list[str]:
    """Riske en çok katkı yapan n faktörü döndürür."""
    contribs = {f: building[f] * w for f, w in WEIGHTS.items()}
    top = sorted(contribs, key=contribs.get, reverse=True)[:n]
    return [FACTOR_LABELS[f] for f in top]


# ---------------------------------------------------------------------------
# YENİLİK 3 – risk_breakdown (her faktörün yüzde katkısı)
# ---------------------------------------------------------------------------

def get_risk_breakdown(building: dict) -> dict:
    """
    Her faktörün ve kategorinin toplam riske yüzde katkısını döndürür.
    Örnek:
        {
          "faktorler": {"hasar_durumu": 42.5, "zemin_riski": 22.8, ...},
          "kategoriler": {"zemin": 65.3, "yapisal": 20.1, "sosyal": 14.6}
        }
    """
    contribs = {f: building[f] * w for f, w in WEIGHTS.items()}
    total = sum(contribs.values()) or 1  # sıfıra bölünmeyi önle

    factor_pct = {
        FACTOR_LABELS[f]: round(v / total * 100, 1)
        for f, v in sorted(contribs.items(), key=lambda x: x[1], reverse=True)
    }

    category_pct: dict[str, float] = {}
    for cat, fields in CATEGORIES.items():
        cat_total = sum(contribs[f] for f in fields)
        category_pct[cat] = round(cat_total / total * 100, 1)

    return {"faktorler": factor_pct, "kategoriler": category_pct}


# ---------------------------------------------------------------------------
# Yardımcı – bina getir veya 404
# ---------------------------------------------------------------------------

def _get_building_or_404(building_id: int) -> dict:
    with get_db() as conn:
        row = conn.execute(
            f"SELECT * FROM buildings WHERE id = ? AND {erzurum_sql_where()}",
            (building_id,),
        ).fetchone()
    if row is None:
        raise HTTPException(
            404,
            f"Erzurum bölgesinde bina bulunamadı: id={building_id}",
        )
    return row_to_dict(row)


def _fetch_erzurum_buildings(conn) -> list[dict]:
    """Yalnızca Erzurum il sınırı içindeki deprem riski binaları."""
    rows = conn.execute(
        f"SELECT * FROM buildings WHERE {erzurum_sql_where()} ORDER BY id"
    ).fetchall()
    return [row_to_dict(r) for r in rows]


@app.on_event("startup")
def on_startup() -> None:
    """Sunucu açılışında Erzurum verilerini API'lerden senkronize eder."""
    try:
        with get_db() as conn:
            bootstrap_erzurum_data(conn, force=False)
            recalibrate_building_risks(conn)
            purge_buildings_outside_erzurum(conn)
            purge_non_risk_buildings(conn)
    except Exception:
        pass  # API geçici kapalıysa mevcut DB ile devam et


@app.post("/data/bootstrap", tags=["Veri"])
def data_bootstrap(force: bool = Query(False, description="Mevcut veriyi yeniden çek")) -> dict:
    """
    Erzurum bina (OSM) ve deprem (Kandilli) verilerini harici API'den çeker.
    Sahte seed bina kayıtlarını temizler.
    """
    with get_db() as conn:
        return bootstrap_erzurum_data(conn, force=force)


def _db_acik_adres(building: dict) -> str:
    """Veritabanındaki açık adres; WPF `adres` alanına gider."""
    acik = (building.get("acik_adres") or "").strip()
    if acik:
        return acik
    return (building.get("adres") or "").strip()


def _building_to_wpf(
    building: dict,
    score: float,
    level: str,
    *,
    use_llm: bool = False,
) -> dict:
    """
    SafeHaven WPF Building modeli.
    Yapısal alanlar doğrudan veritabanından; yalnızca risk alanları hesaplanır.
    """
    # Risk özeti kural tabanlı; LLM yalnızca /ai/full-report içinde kullanılır (tekrar önlenir).
    ai_text = generate_building_ai_summary(building, score, level)
    return {
        "id":             building["id"],
        "mahalle":        building.get("mahalle") or "",
        "adres":          _db_acik_adres(building),
        "bina_yasi":      building["bina_yasi"],
        "kat_sayisi":     building["kat_sayisi"],
        "zemin_riski":    building["zemin_riski"],
        "hasar_durumu":   building["hasar_durumu"],
        "yasli_sayisi":   building["yasli_sayisi"],
        "engelli_sayisi": building["engelli_sayisi"],
        "cocuk_sayisi":   building["cocuk_sayisi"],
        "enlem":          float(building.get("enlem") or 0.0),
        "boylam":         float(building.get("boylam") or 0.0),
        "risk_skoru":     score,
        "risk_seviyesi":  level,
        "oneri":          generate_action_plan(building, score, level),
        "ai_aciklama":    ai_text,
        "yapisal_analiz": generate_building_structural_note(building),
        "karar_faktorleri": generate_building_decision_factors(building, score),
        "tahliye_zorlugu": get_evacuation_difficulty(level),
        "il":             ERZURUM_IL_ADI,
        "deprem_risk_binasi": True,
    }


# ---------------------------------------------------------------------------
# YENİLİK 9 – Yeni bina için Pydantic model
# ---------------------------------------------------------------------------

class BuildingCreate(BaseModel):
    mahalle:        str          = Field(..., example="Kadıköy")
    adres:          str          = Field(..., example="Moda Cad. No:1")
    bina_yasi:      int          = Field(..., ge=0,  le=200, example=30)
    kat_sayisi:     int          = Field(..., ge=1,  le=50,  example=5)
    zemin_riski:    int          = Field(..., ge=1,  le=5,   example=3)
    hasar_durumu:   int          = Field(..., ge=1,  le=5,   example=2)
    yasli_sayisi:   int          = Field(..., ge=0,         example=4)
    engelli_sayisi: int          = Field(..., ge=0,         example=1)
    cocuk_sayisi:   int          = Field(..., ge=0,         example=8)


# ===========================================================================
# ENDPOINTLER
# ===========================================================================

@app.get("/", tags=["Genel"])
def root():
    return {"mesaj": "SafeHaven AI v2 çalışıyor 🚀", "docs": "/docs"}


# ---------------------------------------------------------------------------
# 1. Tüm binaları listele  (YENİLİK 8 – filtreler eklendi)
# ---------------------------------------------------------------------------

@app.get("/buildings", tags=["Binalar"])
def list_buildings(
    mahalle:    Optional[str]  = Query(None, description="Mahalleye göre filtrele"),
    risk_level: Optional[str]  = Query(None, description="Risk seviyesine göre filtrele"),
    min_score:  Optional[float]= Query(None, description="Minimum normalize risk skoru (0-100)"),
    oncelik:    bool           = Query(True, description="Yüksek riskten düşüğe sırala"),
) -> list[dict]:
    """
    **Yalnızca Erzurum ilindeki** deprem riski binalarını WPF formatında döndürür.
    Konut / kamu / iş yeri tipi yapılar; cami, garaj vb. hariç tutulur.
    Varsayılan sıralama: risk skoru yüksekten düşüğe (öncelik listesi).
    """
    with get_db() as conn:
        ensure_address_schema(conn)
        buildings = _fetch_erzurum_buildings(conn)

    scored: list[tuple[float, dict]] = []
    for b in buildings:
        raw   = calculate_raw_score(b)
        score = normalize_score(raw)
        level = get_risk_level(score)

        if mahalle and b.get("mahalle") != mahalle:
            continue
        if risk_level and level != risk_level:
            continue
        if min_score is not None and score < min_score:
            continue

        scored.append((score, _building_to_wpf(b, score, level, use_llm=False)))

    if oncelik:
        scored.sort(key=lambda x: x[0], reverse=True)

    return [item for _, item in scored]


@app.post("/buildings/refresh-addresses", tags=["Binalar"])
def refresh_addresses_endpoint(
    max_geocode: int = Query(250, ge=0, le=500, description="Nominatim ile en fazla kaç adres"),
) -> dict:
    """Tüm binaların mahalle ve açık adres alanlarını OSM/Nominatim ile günceller."""
    with get_db() as conn:
        return refresh_building_addresses(conn, max_geocode=max_geocode)


# ---------------------------------------------------------------------------
# 2. Tek bina detayı
# ---------------------------------------------------------------------------

@app.get("/buildings/{building_id}", tags=["Binalar"])
def get_building(building_id: int) -> dict:
    """Tek bina — veritabanı kaydı + hesaplanan risk alanları (WPF uyumlu)."""
    building = _get_building_or_404(building_id)
    score = normalize_score(calculate_raw_score(building))
    level = get_risk_level(score)
    return _building_to_wpf(building, score, level, use_llm=False)


# ---------------------------------------------------------------------------
# 9. Yeni bina ekle
# ---------------------------------------------------------------------------

@app.post("/buildings", tags=["Binalar"], status_code=201)
def create_building(data: BuildingCreate) -> dict:
    """Yeni bir bina kaydı oluşturur ve oluşturulan kaydı döndürür."""
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO buildings
               (mahalle, adres, bina_yasi, kat_sayisi, zemin_riski,
                hasar_durumu, yasli_sayisi, engelli_sayisi, cocuk_sayisi)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.mahalle, data.adres, data.bina_yasi, data.kat_sayisi,
                data.zemin_riski, data.hasar_durumu, data.yasli_sayisi,
                data.engelli_sayisi, data.cocuk_sayisi,
            ),
        )
        conn.commit()
        new_id = cursor.lastrowid

    return {**data.model_dump(), "id": new_id, "mesaj": "Bina başarıyla eklendi."}


# ---------------------------------------------------------------------------
# 3. Analiz  (YENİLİK 1-4-6 burada devreye giriyor)
# ---------------------------------------------------------------------------

@app.post("/analyze/{building_id}", tags=["Analiz"])
def analyze_building(building_id: int) -> dict[str, Any]:
    """
    Binanın:
    - Normalize edilmiş risk skoru (0-100)
    - Risk seviyesi
    - Top 3 faktör
    - Faktör/kategori katkı yüzdeleri (breakdown)
    - Mahalledeki diğer binalarla karşılaştırma (benchmark)
    - Bu analizi veritabanına kaydeder
    """
    building = _get_building_or_404(building_id)

    raw    = calculate_raw_score(building)
    score  = normalize_score(raw)
    level  = get_risk_level(score)
    top    = get_top_factors(building)
    breakdown = get_risk_breakdown(building)

    # YENİLİK 6 – Mahalle benchmark
    with get_db() as conn:
        mahalle_rows = conn.execute(
            "SELECT * FROM buildings WHERE mahalle = ? AND id != ?",
            (building["mahalle"], building_id),
        ).fetchall()

    mahalle_buildings = [row_to_dict(r) for r in mahalle_rows]
    benchmark: dict[str, Any] = {}
    if mahalle_buildings:
        mahalle_scores = [normalize_score(calculate_raw_score(b)) for b in mahalle_buildings]
        avg = round(sum(mahalle_scores) / len(mahalle_scores), 2)
        benchmark = {
            "mahalle_ortalama_risk":  avg,
            "bina_sayisi_mahallede":  len(mahalle_buildings) + 1,
            "bu_bina_mahalle_ortasi": "Üzerinde" if score > avg else "Altında",
            "fark": round(score - avg, 2),
        }
    else:
        benchmark = {"not": "Mahalledeki tek bina – karşılaştırma yapılamadı."}

    # YENİLİK 4 – Analizi geçmişe kaydet
    now_ts = datetime.now().isoformat(timespec="seconds")
    with get_db() as conn:
        conn.execute(
            "INSERT INTO risk_history (building_id, raw_score, normalized_score, risk_level, analyzed_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (building_id, raw, score, level, now_ts),
        )
        conn.commit()

    wpf = _building_to_wpf(building, score, level, use_llm=True)

    return {
        **wpf,
        "bina_id":        building_id,
        "raw_score":      raw,
        "risk_score":     score,
        "risk_level":     level,
        "top_factors":    top,
        "risk_breakdown": breakdown,
        "benchmark":      benchmark,
        "analyzed_at":    now_ts,
    }


# ---------------------------------------------------------------------------
# 5. Bina risk geçmişi  (YENİLİK 5)
# ---------------------------------------------------------------------------

@app.get("/buildings/{building_id}/history", tags=["Analiz"])
def building_history(building_id: int) -> dict[str, Any]:
    """
    Bir binanın zaman içindeki risk skor değişimini döndürür.
    Her POST /analyze çağrısında kayıt oluşturulur; init_db.py 6 aylık
    sahte geçmiş veri de ekler.
    """
    _get_building_or_404(building_id)  # 404 kontrolü

    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM risk_history WHERE building_id = ? ORDER BY analyzed_at ASC",
            (building_id,),
        ).fetchall()

    if not rows:
        return {"bina_id": building_id, "kayit_sayisi": 0, "gecmis": []}

    history = [row_to_dict(r) for r in rows]

    # Trend hesapla: ilk vs son kayıt farkı
    first_score = history[0]["normalized_score"]
    last_score  = history[-1]["normalized_score"]
    trend = "Artış" if last_score > first_score else ("Düşüş" if last_score < first_score else "Sabit")

    return {
        "bina_id":      building_id,
        "kayit_sayisi": len(history),
        "trend":        trend,
        "ilk_skor":     first_score,
        "son_skor":     last_score,
        "degisim":      round(last_score - first_score, 2),
        "gecmis":       history,
    }


# ---------------------------------------------------------------------------
# 4. Öncelik listesi
# ---------------------------------------------------------------------------

@app.get("/priority-list", tags=["Analiz"])
def priority_list(limit: int = Query(10, ge=1, le=50)) -> list[dict[str, Any]]:
    """
    En riskli binaları sıralı döndürür.
    `limit` parametresiyle kaç bina istediğinizi belirleyebilirsiniz (varsayılan: 10).
    """
    with get_db() as conn:
        buildings = _fetch_erzurum_buildings(conn)

    scored = []
    for b in buildings:
        raw   = calculate_raw_score(b)
        score = normalize_score(raw)
        scored.append({
            "bina_id":    b["id"],
            "mahalle":    b["mahalle"],
            "adres":      _db_acik_adres(b),
            "risk_score": score,
            "risk_skoru": score,
            "risk_level": get_risk_level(score),
            "risk_seviyesi": get_risk_level(score),
            "top_factors": get_top_factors(b),
            "il": ERZURUM_IL_ADI,
        })

    scored.sort(key=lambda x: x["risk_score"], reverse=True)
    return scored[:limit]


# ---------------------------------------------------------------------------
# 7. Mahalle istatistikleri  (YENİLİK 7)
# ---------------------------------------------------------------------------

@app.get("/neighborhood-stats", tags=["İstatistik"])
def neighborhood_stats() -> list[dict[str, Any]]:
    """
    Her mahalle için:
    - Bina sayısı
    - Ortalama normalize risk skoru
    - Acil müdahale bina sayısı
    - Risk dağılımı (kaç Düşük / Orta / Yüksek / Acil)
    Ortalama riske göre azalan sırada döndürür.
    """
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM buildings").fetchall()

    buildings = [row_to_dict(r) for r in rows]

    # Mahalleleri grupla
    mahalle_map: dict[str, list[dict]] = {}
    for b in buildings:
        mahalle_map.setdefault(b["mahalle"], []).append(b)

    result = []
    for mahalle, bilar in mahalle_map.items():
        scores = [normalize_score(calculate_raw_score(b)) for b in bilar]
        level_counts: dict[str, int] = {"Düşük Risk": 0, "Orta Risk": 0, "Yüksek Risk": 0, "Acil Müdahale": 0}
        for s in scores:
            level_counts[get_risk_level(s)] += 1

        result.append({
            "mahalle":              mahalle,
            "bina_sayisi":          len(bilar),
            "ortalama_risk":        round(sum(scores) / len(scores), 2),
            "acil_mudahale_sayisi": level_counts["Acil Müdahale"],
            "risk_dagilimi":        level_counts,
        })

    result.sort(key=lambda x: x["ortalama_risk"], reverse=True)
    return result


# ---------------------------------------------------------------------------
# 5. Genel istatistikler
# ---------------------------------------------------------------------------

@app.get("/stats", tags=["İstatistik"])
def stats() -> dict[str, Any]:
    """Sistemdeki tüm binalar için özet istatistikler."""
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM buildings").fetchall()

    buildings = [row_to_dict(r) for r in rows]
    if not buildings:
        raise HTTPException(404, "Veritabanında bina yok.")

    scores = [normalize_score(calculate_raw_score(b)) for b in buildings]

    # En riskli mahalle: mahalledeki binaların ortalama riski en yüksek olan
    mahalle_scores: dict[str, list[float]] = {}
    for b, s in zip(buildings, scores):
        mahalle_scores.setdefault(b["mahalle"], []).append(s)

    en_riskli_mahalle = max(
        mahalle_scores,
        key=lambda m: sum(mahalle_scores[m]) / len(mahalle_scores[m]),
    )

    level_counts: dict[str, int] = {"Düşük Risk": 0, "Orta Risk": 0, "Yüksek Risk": 0, "Acil Müdahale": 0}
    for s in scores:
        level_counts[get_risk_level(s)] += 1

    return {
        "toplam_bina":          len(buildings),
        "acil_mudahale_sayisi": level_counts["Acil Müdahale"],
        "yuksek_risk_sayisi":   level_counts["Yüksek Risk"],
        "orta_risk_sayisi":     level_counts["Orta Risk"],
        "dusuk_risk_sayisi":    level_counts["Düşük Risk"],
        "ortalama_risk":        round(sum(scores) / len(scores), 2),
        "en_riskli_mahalle":    en_riskli_mahalle,
    }


# ---------------------------------------------------------------------------
# Deprem verileri  — yerel DB + Kandilli Rasathanesi canlı API
# ---------------------------------------------------------------------------

# Kandilli API sabitleri
KANDILLI_BASE    = "https://api.orhanaydogdu.com.tr/deprem"
KANDILLI_HEADERS = {
    "User-Agent": "SafeHaven-AI/3.0",
    "Accept":     "application/json",
}


def _kandilli_get(path: str, params: dict) -> dict:
    """Kandilli REST API'sine GET isteği atar; hata durumunda HTTPException fırlatır."""
    qs  = urllib.parse.urlencode(params)
    url = f"{KANDILLI_BASE}{path}?{qs}"
    req = urllib.request.Request(url, headers=KANDILLI_HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except Exception as exc:
        raise HTTPException(502, f"Kandilli API hatası: {exc}")


def _kandilli_to_eq(item: dict) -> dict:
    """Kandilli API öğesini earthquakes tablosu formatına dönüştürür."""
    coords = item.get("geojson", {}).get("coordinates", [0.0, 0.0])
    lon, lat = float(coords[0]), float(coords[1])
    dt_str = item.get("date_time", "")[:16]   # "2026-05-16 21:27"
    return {
        "earthquake_id": item.get("earthquake_id", ""),
        "tarih":         dt_str,
        "yer":           item.get("title", ""),
        "buyukluk":      float(item.get("mag", 0)),
        "derinlik":      float(item.get("depth", 0)),
        "enlem":         lat,
        "boylam":        lon,
        "provider":      item.get("provider", "kandilli"),
    }


@app.get("/earthquakes", tags=["Depremler"])
def list_earthquakes(
    limit:        int             = Query(50,  ge=1, le=100,
                                          description="Döndürülecek maksimum deprem sayısı"),
    min_buyukluk: Optional[float] = Query(None, ge=0.0, le=10.0,
                                          description="Minimum büyüklük filtresi (Örn: 4.0)"),
) -> list[dict]:
    """
    **Yerel veritabanındaki** deprem listesini yeniden eskiye sıralar.
    Canlı veri için /earthquakes/live, senkronizasyon için /earthquakes/sync kullanın.
    """
    with get_db() as conn:
        eq_count = conn.execute("SELECT COUNT(*) FROM earthquakes").fetchone()[0]
        if eq_count < 10:
            try:
                sync_earthquakes(conn, limit=100)
            except Exception:
                pass
        rows = conn.execute(
            "SELECT * FROM earthquakes ORDER BY tarih DESC LIMIT ?", (limit,)
        ).fetchall()
    result = [row_to_dict(r) for r in rows]
    if min_buyukluk is not None:
        result = [r for r in result if r["buyukluk"] >= min_buyukluk]
    return result


@app.get("/earthquakes/live", tags=["Depremler"])
def earthquakes_live(
    limit:        int             = Query(10,  ge=1, le=100,
                                          description="Döndürülecek deprem sayısı"),
    source:       str             = Query("kandilli",
                                          description="Veri kaynağı: 'kandilli' veya 'afad'"),
    min_buyukluk: Optional[float] = Query(None, ge=0.0, le=10.0,
                                          description="Minimum büyüklük filtresi"),
) -> list[dict]:
    """
    Kandilli / AFAD'dan anlık deprem verisi çeker (son 24 saat).
    Veriler yerel DB'ye kaydedilmez — sadece görüntüleme içindir.
    DB'ye kaydetmek için /earthquakes/sync kullanın.
    """
    if source not in ("kandilli", "afad"):
        raise HTTPException(400, "source 'kandilli' veya 'afad' olmalıdır.")
    data = _kandilli_get(f"/{source}/live", {"limit": limit, "skip": 0})
    if not data.get("status"):
        raise HTTPException(502, f"Kandilli API başarısız: {data}")
    result = [_kandilli_to_eq(i) for i in data.get("result", [])]
    if min_buyukluk is not None:
        result = [r for r in result if r["buyukluk"] >= min_buyukluk]
    return result


@app.get("/earthquakes/sync", tags=["Depremler"])
def earthquakes_sync(
    limit:  int = Query(50, ge=1, le=100,
                        description="Kandilli'den çekilecek deprem sayısı"),
    source: str = Query("kandilli",
                        description="Veri kaynağı: 'kandilli' veya 'afad'"),
) -> dict:
    """
    Kandilli / AFAD'dan canlı veri çekip yerel earthquakes tablosuna kaydeder.
    earthquake_id ile tekilleştirme yapılır — aynı deprem iki kez eklenmez.
    """
    if source not in ("kandilli", "afad"):
        raise HTTPException(400, "source 'kandilli' veya 'afad' olmalıdır.")

    data = _kandilli_get(f"/{source}/live", {"limit": limit, "skip": 0})
    if not data.get("status"):
        raise HTTPException(502, f"Kandilli API başarısız: {data}")

    items   = data.get("result", [])
    added   = 0
    skipped = 0
    now_ts  = datetime.now().isoformat(timespec="seconds")

    with get_db() as conn:
        # Eski DB uyumu: earthquake_id kolonu yoksa ekle
        cols = [r[1] for r in conn.execute("PRAGMA table_info(earthquakes)").fetchall()]
        if "earthquake_id" not in cols:
            conn.execute("ALTER TABLE earthquakes ADD COLUMN earthquake_id TEXT DEFAULT NULL")
            conn.commit()

        for item in items:
            eq    = _kandilli_to_eq(item)
            eq_id = eq["earthquake_id"]
            # Zaten kayıtlıysa atla
            if eq_id and conn.execute(
                "SELECT id FROM earthquakes WHERE earthquake_id = ?", (eq_id,)
            ).fetchone():
                skipped += 1
                continue
            conn.execute(
                """INSERT INTO earthquakes
                   (tarih, yer, buyukluk, derinlik, enlem, boylam, earthquake_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (eq["tarih"], eq["yer"], eq["buyukluk"],
                 eq["derinlik"], eq["enlem"], eq["boylam"], eq_id or None),
            )
            added += 1
        conn.commit()

    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM earthquakes").fetchone()[0]

    return {
        "mesaj":         f"Kandilli sync tamamlandı ({source}).",
        "kaynak":        source,
        "cekilen":       len(items),
        "eklenen":       added,
        "atlanan":       skipped,
        "toplam_deprem": total,
        "synced_at":     now_ts,
    }

# ===========================================================================
# YARDIMCI FONKSİYONLAR (v3)
# ===========================================================================

def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """İki koordinat arasındaki küresel mesafeyi km cinsinden hesaplar (Haversine)."""
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2
         + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2))
         * math.sin(dlon / 2) ** 2)
    return round(R * 2 * math.asin(math.sqrt(a)), 3)


def _get_ap_or_404(ap_id: int) -> dict:
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM assembly_points WHERE id = ?", (ap_id,)
        ).fetchone()
    if row is None:
        raise HTTPException(404, f"Toplanma alanı bulunamadı: id={ap_id}")
    return row_to_dict(row)



# ===========================================================================
# WPF UYUMLULUK — AI Metin + Güvenlik Skoru Hesaplama
# ===========================================================================

def _bina_oneri(risk_level: str) -> str:
    """Bina risk seviyesine göre kısa öneri metni üretir."""
    return {
        "Acil Müdahale": (
            "Bina derhal tahliye edilmeli, yapısal güvenlik incelemesi acil olarak "
            "başlatılmalıdır. AFAD ile koordinasyon sağlanmalıdır."
        ),
        "Yüksek Risk": (
            "6 ay içinde güçlendirme projesi hazırlatılmalı, bina sakinleri "
            "deprem riski konusunda bilinçlendirilmelidir."
        ),
        "Orta Risk": (
            "Periyodik yapısal denetim ve zemin etüdü yaptırılması önerilir. "
            "Sonraki 2 yıl içinde değerlendirme güncellenmelidir."
        ),
        "Düşük Risk": (
            "Rutin yıllık bakım ve denetim yeterlidir. "
            "Bina mevcut standartları karşılamaktadır."
        ),
    }.get(risk_level, "Bina için kapsamlı değerlendirme yapılmalıdır.")


def _bina_ai_aciklama(building: dict, score: float, risk_level: str,
                       top_factors: list[str] | None = None) -> str:
    """Bina AI açıklaması — OpenAI varsa LLM, yoksa fallback."""
    return generate_ai_analysis(building, score, risk_level)


def _safe_zone_guvenlik_skoru(ap: dict) -> float:
    """
    Toplanma alanı güvenlik skorunu hesaplar (0–100).
    Kapasite ve alan büyüklüğüne göre ağırlıklı formül.
    """
    kapasite_score = min(ap["kapasite"] / 10000 * 40, 40.0)   # Maks 40 puan
    alan_score     = min(ap["alan_m2"]   / 20000 * 35, 35.0)   # Maks 35 puan
    base_score     = 25.0                                        # Sabit taban puan
    return round(kapasite_score + alan_score + base_score, 1)


def _safe_zone_doluluk(ap: dict) -> int:
    """
    Veritabanındaki gerçek doluluk değerini döndürür.
    Eğer doluluk alanı yoksa tahmini hesap yapar (geriye uyumluluk).
    """
    if "doluluk" in ap:
        return int(ap["doluluk"])
    return min(int(ap["kapasite"] * 0.16), ap["kapasite"])


def _safe_zone_ai_fields(ap: dict, guvenlik_skoru: float) -> dict:
    """Toplanma alanı AI metinleri — birbirini tekrarlamayan roller."""
    doluluk = _safe_zone_doluluk(ap)
    ap_with_doluluk = {**ap, "doluluk": doluluk, "ulasim_durumu": "Açık"}
    return {
        "ai_aciklama": generate_safe_zone_listing_explanation(ap_with_doluluk, guvenlik_skoru),
        "ai_doluluk": generate_safe_zone_occupancy_note(ap_with_doluluk, doluluk),
        "yonlendirme_gerekce": generate_safe_zone_routing_reason(
            ap_with_doluluk, guvenlik_skoru, doluluk
        ),
    }


def _assembly_point_to_safezone(ap: dict) -> dict:
    """assembly_points DB satırını WPF SafeZone formatına dönüştürür."""
    guvenlik_skoru = _safe_zone_guvenlik_skoru(ap)
    doluluk = _safe_zone_doluluk(ap)
    ai_fields = _safe_zone_ai_fields(ap, guvenlik_skoru)
    return {
        "id":             ap["id"],
        "ad":             ap["ad"],
        "mahalle":        ap["ilce"],          # ilce → mahalle (WPF alanı)
        "kapasite":       ap["kapasite"],
        "doluluk":        doluluk,
        "ulasim_durumu":  "Açık",
        "guvenlik_skoru": guvenlik_skoru,
        **ai_fields,
        "enlem":          ap["lat"],           # lat → enlem (WPF alanı)
        "boylam":         ap["lon"],           # lon → boylam (WPF alanı)
        "engelli_uygun":  ap.get("engelli_uygun", 1),
    }


# ===========================================================================
# PYDANTIC MODELLERİ (v3)
# ===========================================================================

class ResidentsUpdate(BaseModel):
    yasli_sayisi:    int = Field(..., ge=0, example=5,
                                description="65 yaş üstü kişi sayısı")
    engelli_sayisi:  int = Field(..., ge=0, example=2,
                                description="Engelli birey sayısı")
    cocuk_sayisi:    int = Field(..., ge=0, example=8,
                                description="0-14 yaş çocuk sayısı")


class AssemblyPointCreate(BaseModel):
    ad:            str   = Field(..., example="Merkez Parkı")
    lat:           float = Field(..., ge=-90,  le=90,  example=39.9083)
    lon:           float = Field(..., ge=-180, le=180, example=41.2769)
    kapasite:      int   = Field(..., ge=0,            example=3000)
    alan_m2:       float = Field(..., ge=0.0,          example=5000.0)
    ilce:          str   = Field(..., example="Yakutiye")
    doluluk:       int   = Field(0,   ge=0,            example=180)
    engelli_uygun: int   = Field(1,   ge=0, le=1,      example=1)


# ===========================================================================
# SAKIN VERİSİ  (YENİLİK 2)
# ===========================================================================

@app.get("/buildings/{building_id}/residents", tags=["Sakinler"])
def get_residents(building_id: int) -> dict:
    """
    Binanın sakin verisini döndürür.
    Önce `residents` tablosuna bakılır; kayıt yoksa `buildings` tablosundaki
    başlangıç değerleri döndürülür.
    """
    building = _get_building_or_404(building_id)
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM residents WHERE building_id = ?", (building_id,)
        ).fetchone()
    if row:
        data = row_to_dict(row)
        data["source"] = "residents_table"
    else:
        data = {
            "building_id":     building_id,
            "yasli_sayisi":    building["yasli_sayisi"],
            "engelli_sayisi":  building["engelli_sayisi"],
            "cocuk_sayisi":    building["cocuk_sayisi"],
            "updated_at":      None,
            "source":          "buildings_table_default",
        }
    return data


@app.put("/buildings/{building_id}/residents", tags=["Sakinler"])
def update_residents(building_id: int, data: ResidentsUpdate) -> dict:
    """
    Binanın sakin verisini günceller.
    - `buildings` tablosundaki yasli/engelli/cocuk kolonlarını günceller
      (risk skoru hesabına anında yansır).
    - `residents` tablosuna zaman damgalı kayıt oluşturur/günceller.
    """
    _get_building_or_404(building_id)  # 404 kontrolü
    now_ts = datetime.now().isoformat(timespec="seconds")

    with get_db() as conn:
        # buildings tablosunu güncelle
        conn.execute(
            """UPDATE buildings
               SET yasli_sayisi=?, engelli_sayisi=?, cocuk_sayisi=?
               WHERE id=?""",
            (data.yasli_sayisi, data.engelli_sayisi, data.cocuk_sayisi, building_id),
        )
        # residents tablosuna upsert
        conn.execute(
            """INSERT INTO residents (building_id, yasli_sayisi, engelli_sayisi, cocuk_sayisi, updated_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(building_id) DO UPDATE SET
                 yasli_sayisi=excluded.yasli_sayisi,
                 engelli_sayisi=excluded.engelli_sayisi,
                 cocuk_sayisi=excluded.cocuk_sayisi,
                 updated_at=excluded.updated_at""",
            (building_id, data.yasli_sayisi, data.engelli_sayisi, data.cocuk_sayisi, now_ts),
        )
        conn.commit()

    return {
        "building_id":    building_id,
        "yasli_sayisi":   data.yasli_sayisi,
        "engelli_sayisi": data.engelli_sayisi,
        "cocuk_sayisi":   data.cocuk_sayisi,
        "updated_at":     now_ts,
        "mesaj":          "Sakin verisi güncellendi.",
    }


# ===========================================================================
# TOPLANMA ALANLARI CRUD  (YENİLİK 4 & 5)
# ===========================================================================

@app.get("/assembly-points", tags=["Toplanma Alanları"])
def list_assembly_points(ilce: Optional[str] = Query(None, description="İlçeye göre filtrele")) -> list[dict]:
    """Tüm toplanma alanlarını listeler. `ilce` parametresiyle filtrelenebilir."""
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM assembly_points ORDER BY id").fetchall()
    result = [row_to_dict(r) for r in rows]
    if ilce:
        result = [r for r in result if r["ilce"] == ilce]
    return result


# NOT: /assembly-points/map, /{ap_id}'den ÖNCE tanımlanmalı (FastAPI routing)
@app.get("/assembly-points/map", tags=["Toplanma Alanları"])
def assembly_points_map(
    radius_km: float = Query(1.0, ge=0.1, le=50.0,
                             description="Toplanma alanına yakın bina arama yarıçapı (km)")
) -> dict:
    """
    Tüm toplanma alanlarını ve her birine `radius_km` km içindeki binaları
    GeoJSON FeatureCollection formatında döndürür.
    Frontend harita kütüphaneleri (Leaflet, MapLibre) doğrudan kullanabilir.
    """
    with get_db() as conn:
        ap_rows  = conn.execute("SELECT * FROM assembly_points").fetchall()
        bld_rows = conn.execute(
            "SELECT id, mahalle, adres, enlem, boylam FROM buildings WHERE enlem != 0"
        ).fetchall()

    assembly_points_list = [row_to_dict(r) for r in ap_rows]
    buildings_list       = [row_to_dict(r) for r in bld_rows]

    features = []

    # Toplanma alanı feature'ları
    for ap in assembly_points_list:
        nearby = []
        for b in buildings_list:
            dist = haversine_km(ap["lat"], ap["lon"], b["enlem"], b["boylam"])
            if dist <= radius_km:
                nearby.append({"id": b["id"], "adres": b["adres"],
                               "mahalle": b["mahalle"], "mesafe_km": dist})
        nearby.sort(key=lambda x: x["mesafe_km"])

        features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [ap["lon"], ap["lat"]]},
            "properties": {
                "feature_type":  "assembly_point",
                "id":            ap["id"],
                "ad":            ap["ad"],
                "ilce":          ap["ilce"],
                "kapasite":      ap["kapasite"],
                "alan_m2":       ap["alan_m2"],
                "nearby_buildings": nearby,
            },
        })

    # Bina feature'ları
    for b in buildings_list:
        features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [b["boylam"], b["enlem"]]},
            "properties": {
                "feature_type": "building",
                "id":           b["id"],
                "adres":        b["adres"],
                "mahalle":      b["mahalle"],
            },
        })

    return {"type": "FeatureCollection", "features": features}


@app.get("/assembly-points/{ap_id}", tags=["Toplanma Alanları"])
def get_assembly_point(ap_id: int) -> dict:
    """Belirtilen toplanma alanının detaylarını döndürür."""
    return _get_ap_or_404(ap_id)


@app.post("/assembly-points", tags=["Toplanma Alanları"], status_code=201)
def create_assembly_point(data: AssemblyPointCreate) -> dict:
    """Yeni bir toplanma alanı ekler."""
    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO assembly_points (ad, lat, lon, kapasite, alan_m2, ilce, doluluk, engelli_uygun) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (data.ad, data.lat, data.lon, data.kapasite, data.alan_m2, data.ilce,
             data.doluluk, data.engelli_uygun),
        )
        conn.commit()
        new_id = cur.lastrowid
    return {**data.model_dump(), "id": new_id, "mesaj": "Toplanma alanı eklendi."}


@app.put("/assembly-points/{ap_id}", tags=["Toplanma Alanları"])
def update_assembly_point(ap_id: int, data: AssemblyPointCreate) -> dict:
    """Mevcut toplanma alanını günceller."""
    _get_ap_or_404(ap_id)  # 404 kontrolü
    with get_db() as conn:
        conn.execute(
            """UPDATE assembly_points
               SET ad=?, lat=?, lon=?, kapasite=?, alan_m2=?, ilce=?,
                   doluluk=?, engelli_uygun=?
               WHERE id=?""",
            (data.ad, data.lat, data.lon, data.kapasite, data.alan_m2, data.ilce,
             data.doluluk, data.engelli_uygun, ap_id),
        )
        conn.commit()
    return {**data.model_dump(), "id": ap_id, "mesaj": "Toplanma alanı güncellendi."}


@app.delete("/assembly-points/{ap_id}", tags=["Toplanma Alanları"])
def delete_assembly_point(ap_id: int) -> dict:
    """Toplanma alanını siler."""
    _get_ap_or_404(ap_id)
    with get_db() as conn:
        conn.execute("DELETE FROM assembly_points WHERE id = ?", (ap_id,))
        conn.commit()
    return {"mesaj": f"Toplanma alanı silindi: id={ap_id}"}


# ===========================================================================
# EN YAKIN TOPLANMA ALANI  (YENİLİK 6)
# ===========================================================================

@app.get("/buildings/{building_id}/nearest-assembly", tags=["Toplanma Alanları"])
def nearest_assembly(building_id: int) -> dict:
    """
    Binanın koordinatlarına en yakın toplanma alanını Haversine formülüyle bulur.
    Tüm toplanma alanlarını mesafeye göre sıralı döndürür.
    """
    building = _get_building_or_404(building_id)
    lat, lon = building.get("enlem", 0.0), building.get("boylam", 0.0)
    if lat == 0.0 and lon == 0.0:
        raise HTTPException(400, "Bu binanın koordinat verisi yok (enlem/boylam = 0).")

    with get_db() as conn:
        rows = conn.execute("SELECT * FROM assembly_points").fetchall()

    if not rows:
        raise HTTPException(404, "Veritabanında hiç toplanma alanı yok.")

    ranked = []
    for r in rows:
        ap = row_to_dict(r)
        dist = haversine_km(lat, lon, ap["lat"], ap["lon"])
        ranked.append({**ap, "mesafe_km": dist})

    ranked.sort(key=lambda x: x["mesafe_km"])

    return {
        "bina_id":           building_id,
        "bina_adres":        building["adres"],
        "bina_lat":          lat,
        "bina_lon":          lon,
        "en_yakin":          ranked[0],
        "tum_toplanma_alanlari": ranked,
    }


# ===========================================================================
# OSM OVERPASS SYNC  (YENİLİK 1 & 8)
# ===========================================================================

OVERPASS_URL  = "https://overpass-api.de/api/interpreter"
ERZURUM_BBOX  = ERZURUM_BBOX_OVERPASS


def _extract_osm_building(element: dict) -> Optional[dict]:
    """Overpass API element'inden Erzurum deprem riski bina verisini çıkarır."""
    center = element.get("center")
    if not center:
        return None
    tags = element.get("tags", {})
    lat, lon = center["lat"], center["lon"]
    if not is_in_erzurum_bbox(lat, lon) or not is_deprem_risk_building(tags):
        return None

    # Adres: en iyi mevcut tag kombinasyonu
    street = tags.get("addr:street", "")
    num    = tags.get("addr:housenumber", "")
    adres  = tags.get("addr:full") or (f"{street} No:{num}".strip() if street else "") or tags.get("name", "")

    mahalle   = (tags.get("addr:suburb") or tags.get("addr:neighbourhood")
                 or tags.get("addr:district") or "")
    kat_str   = tags.get("building:levels", "1")
    try:
        kat_sayisi = max(1, int(float(kat_str)))
    except (ValueError, TypeError):
        kat_sayisi = 1

    return {
        "osm_id":    str(element["id"]),
        "adres":     adres[:255],
        "mahalle":   mahalle[:100],
        "kat_sayisi": kat_sayisi,
        "bina_yasi": 0,
        "lat":       center["lat"],
        "lon":       center["lon"],
        "raw_tags":  json.dumps(tags, ensure_ascii=False)[:2000],
    }


@app.get("/osm/sync", tags=["OSM"])
def osm_sync(
    limit: int = Query(200, ge=1, le=1000,
                       description="Çekilecek maksimum bina sayısı")
) -> dict:
    """
    Overpass API'den Erzurum sınırları içindeki binaları çeker ve
    `building_layers` tablosuna kaydeder.
    - Mevcut `osm_id` → güncellenir.
    - Yeni `osm_id`   → eklenir.
    Bounding box: Erzurum merkez (39.72–39.98°N, 41.05–41.55°E).
    """
    query = f"""[out:json][timeout:60];
way["building"]({ERZURUM_BBOX});
out center tags {limit};
"""
    payload = urllib.parse.urlencode({"data": query}).encode()
    req = urllib.request.Request(
        OVERPASS_URL, data=payload,
        headers={"User-Agent": "SafeHaven-AI/3.0", "Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req, timeout=70) as resp:
            osm_data = json.loads(resp.read())
    except Exception as exc:
        raise HTTPException(502, f"Overpass API hatası: {exc}")

    elements = osm_data.get("elements", [])
    now_ts   = datetime.now().isoformat(timespec="seconds")

    added = updated = skipped = 0
    with get_db() as conn:
        for el in elements:
            b = _extract_osm_building(el)
            if not b:
                skipped += 1
                continue
            existing = conn.execute(
                "SELECT id FROM building_layers WHERE osm_id = ?", (b["osm_id"],)
            ).fetchone()
            if existing:
                conn.execute(
                    """UPDATE building_layers
                       SET adres=?, mahalle=?, kat_sayisi=?, lat=?, lon=?, raw_tags=?, synced_at=?
                       WHERE osm_id=?""",
                    (b["adres"], b["mahalle"], b["kat_sayisi"],
                     b["lat"], b["lon"], b["raw_tags"], now_ts, b["osm_id"]),
                )
                updated += 1
            else:
                conn.execute(
                    """INSERT INTO building_layers
                       (osm_id, adres, mahalle, kat_sayisi, bina_yasi, lat, lon, raw_tags, synced_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (b["osm_id"], b["adres"], b["mahalle"], b["kat_sayisi"],
                     b["bina_yasi"], b["lat"], b["lon"], b["raw_tags"], now_ts),
                )
                added += 1
        conn.commit()

    total = conn.execute if False else None  # sadece mypy için
    with get_db() as conn:
        total_layers = conn.execute("SELECT COUNT(*) FROM building_layers").fetchone()[0]

    return {
        "mesaj":         "OSM sync tamamlandı.",
        "erzurum_bbox":  ERZURUM_BBOX,
        "osm_eleman":    len(elements),
        "eklenen":       added,
        "guncellenen":   updated,
        "atlanan":       skipped,
        "toplam_katman": total_layers,
        "synced_at":     now_ts,
    }


@app.get("/building-layers", tags=["OSM"])
def list_building_layers(
    mahalle: Optional[str] = Query(None),
    limit:   int           = Query(100, ge=1, le=1000),
) -> list[dict]:
    """
    `building_layers` tablosundaki OSM kökenli bina verilerini listeler.
    `/osm/sync` çalıştırıldıktan sonra dolmaya başlar.
    """
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM building_layers ORDER BY id LIMIT ?", (limit,)
        ).fetchall()
    result = [row_to_dict(r) for r in rows]
    if mahalle:
        result = [r for r in result if r["mahalle"] == mahalle]
    return result

# ===========================================================================
# TRADRES ADRES API  — Türkiye İdari Bölge Verileri
# ===========================================================================
#
# API: https://api.tradres.com.tr
# Docs: X-Api-Key header ile kimlik doğrulama yapılır.
# parentId=25 → Erzurum il kodu
# level seçenekleri: province | town | district | neighbourhood | street

TRADRES_API_KEY      = os.getenv(
    "TRADRES_API_KEY", "trd_live_wBW4BALd3cCaJJgrsXEYb6o2TqngUS7h"
)
TRADRES_PROVIDERS_URL = "https://api.tradres.com.tr/public/v1/catalog/providers"
TRADRES_BASE_URL     = "https://api.tradres.com.tr/public/v1/catalog/providers/localsqlite/nodes"
TRADRES_HEADERS      = {
    "X-Api-Key": TRADRES_API_KEY,
    "Accept":    "application/json",
}


def _tradres_get(params: dict) -> list:
    """Tradres API'sine GET isteği atar ve liste döndürür."""
    qs  = urllib.parse.urlencode(params)
    url = f"{TRADRES_BASE_URL}?{qs}"
    req = urllib.request.Request(url, headers=TRADRES_HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as exc:
        raise HTTPException(502, f"Tradres API hatası: {exc}")


@app.get("/address/provinces", tags=["Adres"])
def list_provinces(take: int = Query(100, ge=1, le=200)) -> list[dict]:
    """
    Türkiye'deki tüm illeri listeler (Tradres API).
    """
    data = _tradres_get({"level": "province", "take": take})
    return [{"id": d["id"], "name": d["name"], "level": d["level"]} for d in data]


@app.get("/address/towns", tags=["Adres"])
def list_towns(
    parent_id: int = Query(25,  description="Üst il ID'si (varsayılan: 25 = Erzurum)"),
    take:      int = Query(200, ge=1, le=500),
) -> list[dict]:
    """
    Belirtilen ile ait ilçeleri listeler (Tradres API).
    Varsayılan: Erzurum (parentId=25).
    """
    data = _tradres_get({"level": "town", "parentId": parent_id, "take": take})
    return [{"id": d["id"], "name": d["name"], "level": d["level"], "parentId": d["parentId"]} for d in data]


@app.get("/address/districts", tags=["Adres"])
def list_districts(
    parent_id: int = Query(..., description="Üst ilçe ID'si (towns endpoint'inden alınır)"),
    take:      int = Query(200, ge=1, le=500),
) -> list[dict]:
    """
    Belirtilen ilçeye ait semtleri / beldeleri listeler (Tradres API).
    Önce `/address/towns` ile ilçe ID'sini öğrenin.
    """
    data = _tradres_get({"level": "district", "parentId": parent_id, "take": take})
    return [{"id": d["id"], "name": d["name"], "level": d["level"], "parentId": d["parentId"]} for d in data]


@app.get("/address/neighbourhoods", tags=["Adres"])
def list_neighbourhoods(
    parent_id: int = Query(..., description="Üst semt/belde ID'si"),
    take:      int = Query(200, ge=1, le=500),
) -> list[dict]:
    """
    Belirtilen semte ait mahalleleri listeler (Tradres API).
    Önce `/address/districts` ile semt ID'sini öğrenin.
    """
    data = _tradres_get({"level": "neighbourhood", "parentId": parent_id, "take": take})
    return [{"id": d["id"], "name": d["name"], "level": d["level"], "parentId": d["parentId"]} for d in data]


@app.get("/address/search", tags=["Adres"])
def search_address(
    q:         str = Query(..., min_length=2, description="Aranacak yer adı (min 2 karakter)"),
    level:     str = Query("town", description="Seviye: province | town | district | neighbourhood"),
    parent_id: Optional[int] = Query(None, description="Üst bölge ID'si ile daralt"),
    take:      int = Query(50, ge=1, le=200),
) -> list[dict]:
    """
    Tradres API üzerinden yer adı araması yapar.
    Sonuçlar `q` metnine göre (büyük/küçük harf duyarsız) filtrelenir.
    """
    params: dict = {"level": level, "take": take}
    if parent_id is not None:
        params["parentId"] = parent_id

    data = _tradres_get(params)

    # İsim bazlı filtreleme (API sunucu tarafında arama desteklemiyorsa client tarafında yap)
    q_lower = q.lower()
    filtered = [d for d in data if q_lower in d.get("name", "").lower()]

    return [
        {"id": d["id"], "name": d["name"], "level": d["level"],
         "parentId": d.get("parentId")}
        for d in filtered
    ]


@app.get("/erzurum-adresleri", tags=["Adres"])
def get_erzurum_data() -> Any:
    """
    Tradres sağlayıcı kataloğunu döndürür (X-Api-Key ile kimlik doğrulama).
  """
    from tradres_client import get_erzurum_providers

    return get_erzurum_providers()


# ===========================================================================
# SAFE ZONE ENDPOINT'LERİ — WPF SafeZone formatı
# ===========================================================================

@app.get("/safe-zones", tags=["Güvenli Alanlar"])
def list_safe_zones(
    ilce:      Optional[str]   = Query(None, description="İlçeye göre filtrele"),
    min_skor:  Optional[float] = Query(None, ge=0, le=100,
                                        description="Minimum güvenlik skoru"),
) -> list[dict]:
    """
    Tüm toplanma alanlarını **WPF SafeZone formatında** döndürür.

    Alan eşleşmesi:
    - `assembly_points.lat`      → `enlem`
    - `assembly_points.lon`      → `boylam`
    - `assembly_points.ilce`     → `mahalle`
    - hesaplanan                 → `guvenlik_skoru`, `doluluk`, `ai_aciklama`
    - sabit                      → `ulasim_durumu = "Açık"`
    """
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM assembly_points ORDER BY id").fetchall()

    result = []
    for ap in [row_to_dict(r) for r in rows]:
        sz = _assembly_point_to_safezone(ap)
        if ilce     and sz["mahalle"]        != ilce:     continue
        if min_skor is not None and sz["guvenlik_skoru"] < min_skor: continue
        result.append(sz)

    # Güvenlik skoruna göre yüksekten düşüğe sırala
    result.sort(key=lambda x: x["guvenlik_skoru"], reverse=True)
    return result


@app.post("/safe-zone/analyze/{ap_id}", tags=["Güvenli Alanlar"])
def analyze_safe_zone(ap_id: int) -> dict:
    """
    Tek bir toplanma alanı için **güvenlik skoru ve AI açıklaması** üretir.
    WPF'nin POST /safe-zone/analyze/{id} çağrısına karşılık gelir.
    """
    ap = _get_ap_or_404(ap_id)
    guvenlik_skoru = _safe_zone_guvenlik_skoru(ap)
    doluluk = _safe_zone_doluluk(ap)
    ai_fields = _safe_zone_ai_fields(ap, guvenlik_skoru)

    return {
        "id":             ap["id"],
        "ad":             ap["ad"],
        "mahalle":        ap["ilce"],
        "kapasite":       ap["kapasite"],
        "doluluk":        doluluk,
        "ulasim_durumu":  "Açık",
        "guvenlik_skoru": guvenlik_skoru,
        **ai_fields,
        "enlem":          ap["lat"],
        "boylam":         ap["lon"],
        "alan_m2":        ap["alan_m2"],
        "engelli_uygun":  ap.get("engelli_uygun", 1),
    }


# ===========================================================================
# AI AJAN ENDPOİNT'LERİ — ai_agent.py fonksiyonlarını API'ye bağlar
# ===========================================================================

@app.get("/ai/full-report/{building_id}", tags=["AI Ajan"])
def ai_full_report(building_id: int) -> dict:
    """
    Bir bina için tam AI raporu üretir:
    - Risk analizi (LLM / fallback)
    - Aksiyon planı
    - Etik denetim
    - Vatandaş mesajı
    - En uygun güvenli alan önerisi (mesafe + kapasite + engelli erişimi)
    - Kapasite uyarısı
    - Karar açıklaması (Explainable AI)
    """
    building = _get_building_or_404(building_id)

    raw   = calculate_raw_score(building)
    score = normalize_score(raw)
    level = get_risk_level(score)

    # Güvenli alanları DB'den al
    with get_db() as conn:
        ap_rows = conn.execute("SELECT * FROM assembly_points").fetchall()
    safe_zones_list = [row_to_dict(r) for r in ap_rows]

    # ai_agent fonksiyonlarıyla eşle (lat/lon → enlem/boylam alias)
    safe_zones_for_ai = []
    for ap in safe_zones_list:
        safe_zones_for_ai.append({
            **ap,
            "enlem": ap["lat"],
            "boylam": ap["lon"],
        })

    report = generate_full_report(building, score, level, safe_zones_for_ai)

    return {
        "bina_id":       building_id,
        "adres":         building["adres"],
        "mahalle":       building["mahalle"],
        "risk_score":    score,
        "risk_level":    level,
        **report,
    }


@app.get("/ai/earthquake-summary", tags=["AI Ajan"])
def ai_earthquake_summary(
    limit:     int = Query(20, ge=1, le=100, description="Değerlendirilecek deprem sayısı"),
    city_name: str = Query("Erzurum",        description="Şehir adı"),
) -> dict:
    """
    Yerel veritabanındaki son depremleri AI ile değerlendirir.
    Deprem aktivite seviyesi, en yüksek büyüklük ve belediye önerisi döndürür.
    """
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM earthquakes ORDER BY tarih DESC LIMIT ?", (limit,)
        ).fetchall()

    earthquakes_list = [row_to_dict(r) for r in rows]
    summary_text = generate_earthquake_ai_summary(earthquakes_list, city_name)

    return {
        "city":              city_name,
        "earthquake_count":  len(earthquakes_list),
        "ai_summary":        summary_text,
    }


@app.get("/ai/city-summary", tags=["AI Ajan"])
def ai_city_summary(
    city_name: str = Query("Erzurum", description="Şehir adı"),
) -> dict:
    """
    Şehir geneli AI durum özeti üretir.
    Binalar, güvenli alanlar ve deprem verileri birlikte değerlendirilir.
    """
    with get_db() as conn:
        bld_rows = conn.execute("SELECT * FROM buildings").fetchall()
        ap_rows  = conn.execute("SELECT * FROM assembly_points").fetchall()
        eq_rows  = conn.execute(
            "SELECT * FROM earthquakes ORDER BY tarih DESC LIMIT 50"
        ).fetchall()

    # Binalara risk seviyesi ekle
    buildings_for_ai = []
    for r in bld_rows:
        b = row_to_dict(r)
        raw   = calculate_raw_score(b)
        score = normalize_score(raw)
        b["risk_level"]    = get_risk_level(score)
        b["risk_seviyesi"] = b["risk_level"]
        buildings_for_ai.append(b)

    safe_zones_for_ai = [row_to_dict(r) for r in ap_rows]
    earthquakes_for_ai = [row_to_dict(r) for r in eq_rows]

    result = generate_city_ai_summary(
        buildings_for_ai, safe_zones_for_ai, earthquakes_for_ai, city_name
    )

    return result
