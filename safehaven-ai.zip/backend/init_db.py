"""
init_db.py  –  SafeHaven AI  v3
--------------------------------
Tablolar:
  - buildings       : Yapısal + sosyal bina verisi (fake seed, Istanbul)
  - building_layers : OSM'den gelen ham yapısal veri (Erzurum gerçek binalar)
  - residents       : Kullanıcı tarafından girilen sakin verisi (PUT /buildings/{id}/residents)
  - risk_history    : POST /analyze geçmişi (6 aylık sahte başlangıç verisi)
  - assembly_points : Toplanma alanları (Erzurum seed verisi)
"""

import sqlite3
import os
import random
import json
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "database.db")

# ---------------------------------------------------------------------------
# DDL
# ---------------------------------------------------------------------------

CREATE_BUILDINGS_SQL = """
CREATE TABLE IF NOT EXISTS buildings (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    mahalle        TEXT    NOT NULL,
    adres          TEXT    NOT NULL,
    bina_yasi      INTEGER NOT NULL DEFAULT 0,
    kat_sayisi     INTEGER NOT NULL DEFAULT 1,
    zemin_riski    INTEGER NOT NULL DEFAULT 1,
    hasar_durumu   INTEGER NOT NULL DEFAULT 1,
    yasli_sayisi   INTEGER NOT NULL DEFAULT 0,
    engelli_sayisi INTEGER NOT NULL DEFAULT 0,
    cocuk_sayisi   INTEGER NOT NULL DEFAULT 0,
    enlem          REAL    NOT NULL DEFAULT 0.0,
    boylam         REAL    NOT NULL DEFAULT 0.0,
    osm_id         TEXT    DEFAULT NULL
);
"""

CREATE_BUILDING_LAYERS_SQL = """
CREATE TABLE IF NOT EXISTS building_layers (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    osm_id     TEXT    UNIQUE NOT NULL,
    adres      TEXT    DEFAULT '',
    mahalle    TEXT    DEFAULT '',
    kat_sayisi INTEGER DEFAULT 1,
    bina_yasi  INTEGER DEFAULT 0,
    lat        REAL    NOT NULL,
    lon        REAL    NOT NULL,
    raw_tags   TEXT    DEFAULT '{}',
    synced_at  TEXT    NOT NULL
);
"""

CREATE_RESIDENTS_SQL = """
CREATE TABLE IF NOT EXISTS residents (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    building_id     INTEGER NOT NULL UNIQUE REFERENCES buildings(id) ON DELETE CASCADE,
    yasli_sayisi    INTEGER NOT NULL DEFAULT 0,
    engelli_sayisi  INTEGER NOT NULL DEFAULT 0,
    cocuk_sayisi    INTEGER NOT NULL DEFAULT 0,
    updated_at      TEXT    NOT NULL
);
"""

CREATE_HISTORY_SQL = """
CREATE TABLE IF NOT EXISTS risk_history (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    building_id      INTEGER NOT NULL REFERENCES buildings(id),
    raw_score        REAL    NOT NULL,
    normalized_score REAL    NOT NULL,
    risk_level       TEXT    NOT NULL,
    analyzed_at      TEXT    NOT NULL
);
"""

CREATE_ASSEMBLY_POINTS_SQL = """
CREATE TABLE IF NOT EXISTS assembly_points (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ad            TEXT    NOT NULL,
    lat           REAL    NOT NULL,
    lon           REAL    NOT NULL,
    kapasite      INTEGER NOT NULL DEFAULT 0,
    alan_m2       REAL    NOT NULL DEFAULT 0.0,
    ilce          TEXT    NOT NULL DEFAULT '',
    doluluk       INTEGER NOT NULL DEFAULT 0,
    engelli_uygun INTEGER NOT NULL DEFAULT 1
);
"""

# ---------------------------------------------------------------------------
# DDL: Deprem verileri (AFAD/Kandilli formatına benzer)
# ---------------------------------------------------------------------------

CREATE_EARTHQUAKES_SQL = """
CREATE TABLE IF NOT EXISTS earthquakes (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    tarih     TEXT    NOT NULL,   -- 'YYYY-MM-DD HH:MM' formatı
    yer       TEXT    NOT NULL,   -- Örn: 'Erzurum / Yakutiye'
    buyukluk  REAL    NOT NULL,   -- Richter / Mw
    derinlik  REAL    NOT NULL,   -- km
    enlem     REAL    NOT NULL,
    boylam    REAL    NOT NULL
);
"""

# ---------------------------------------------------------------------------
# Seed: Bina verileri (Istanbul fake data)
# (mahalle, adres, bina_yasi, kat_sayisi, zemin_riski, hasar_durumu,
#  yasli_sayisi, engelli_sayisi, cocuk_sayisi, enlem, boylam)
# ---------------------------------------------------------------------------

BUILDINGS_DATA = [
    # --- ACİL MÜDAHALE ---
    ("Karşıyaka",    "Atatürk Cad. No:12",          52, 6, 5, 5, 14, 6, 10, 41.0662, 28.9925),
    ("Bağcılar",     "Cumhuriyet Sok. No:3",         48, 7, 5, 4, 10, 4, 15, 41.0397, 28.8567),
    ("Sultangazi",   "İnönü Cad. No:88",             55, 8, 4, 5, 18, 5,  8, 41.1073, 28.8989),
    # --- YÜKSEK RİSK ---
    ("Esenler",      "Fatih Sok. No:21",             40, 5, 4, 4,  8, 3, 12, 41.0436, 28.8756),
    ("Güngören",     "Mimar Sinan Cad. No:7",        38, 6, 5, 3,  6, 2,  9, 41.0208, 28.8742),
    ("Bağcılar",     "Zübeyde Hanım Sk. No:9",       45, 5, 3, 5, 12, 6,  7, 41.0351, 28.8601),
    ("Sultangazi",   "Yıldırım Beyazıt Sk. No:4",    42, 7, 4, 4,  9, 4, 11, 41.1112, 28.9012),
    # --- ORTA RİSK ---
    ("Beylikdüzü",   "Barış Mah. No:33",             25, 8, 3, 2,  4, 1, 20, 41.0021, 28.6422),
    ("Esenyurt",     "Marmara Cad. No:17",           30, 5, 3, 3,  5, 2,  8, 41.0328, 28.6726),
    ("Avcılar",      "Deniz Sk. No:5",               28, 4, 4, 2,  3, 1,  6, 40.9793, 28.7219),
    ("Küçükçekmece", "Çınar Cad. No:44",             33, 6, 2, 3,  7, 2, 10, 41.0026, 28.7793),
    ("Pendik",       "Sahil Yolu No:12",             20, 5, 3, 2,  2, 0,  9, 40.8776, 29.2317),
    ("Ümraniye",     "Alemdağ Cad. No:67",           27, 7, 2, 2,  4, 1, 14, 41.0165, 29.1169),
    ("Maltepe",      "Bağdat Cad. No:102",           22, 6, 2, 3,  3, 1,  8, 40.9351, 29.1327),
    # --- DÜŞÜK RİSK ---
    ("Beşiktaş",     "Nispetiye Cad. No:8",           8, 3, 1, 1,  1, 0,  3, 41.0434, 29.0094),
    ("Sarıyer",      "Tarabya Yolu No:14",            10, 4, 1, 1,  0, 0,  4, 41.1726, 29.0531),
    ("Şişli",        "Büyükdere Cad. No:99",          5, 5, 1, 1,  2, 0,  5, 41.0602, 28.9877),
    ("Üsküdar",      "Çamlıca Sk. No:3",             12, 3, 1, 1,  1, 0,  2, 41.0234, 29.0152),
    ("Kadıköy",      "Moda Cad. No:55",               7, 4, 1, 1,  0, 0,  3, 40.9908, 29.0233),
    ("Bakırköy",     "İnkılap Cad. No:18",           15, 5, 2, 1,  3, 1,  7, 40.9795, 28.8732),
    ("Ataşehir",     "Kayışdağı Cad. No:77",          9, 6, 1, 1,  1, 0,  6, 41.0043, 29.1252),
    ("Bahçelievler", "Kocatepe Sk. No:22",           18, 4, 2, 2,  4, 1,  8, 41.0007, 28.8611),
    ("Zeytinburnu",  "Merkezefendi Cad. No:6",       35, 5, 3, 3,  5, 2,  9, 41.0003, 28.9058),
    ("Fatih",        "Akdeniz Cad. No:31",           40, 3, 2, 3,  8, 3,  5, 41.0176, 28.9497),
    ("Eyüpsultan",   "Nişanca Sk. No:10",            30, 4, 2, 2,  4, 1,  7, 41.0594, 28.9333),
]

# ---------------------------------------------------------------------------
# Seed: Toplanma Alanları (Erzurum)
# (ad, lat, lon, kapasite, alan_m2, ilce, doluluk, engelli_uygun)
# ---------------------------------------------------------------------------

ASSEMBLY_POINTS_DATA = [
    ("Yakutiye Stadyumu",                    39.9083, 41.2769, 5000, 8500.0,  "Yakutiye",    320, 1),
    ("Atatürk Üniversitesi Spor Sahası",     39.9192, 41.2583, 8000, 15000.0, "Yakutiye",    510, 1),
    ("Cumhuriyet Meydanı",                   39.9054, 41.2710, 3000, 5000.0,  "Yakutiye",    180, 1),
    ("Aziziye Parkı",                        39.9020, 41.2745, 4000, 7200.0,  "Aziziye",     240, 1),
    ("Palandöken Olimpik Kayak Parkı",       39.8780, 41.2650, 6000, 12000.0, "Palandöken",  150, 0),
    ("Kazım Karabekir Parkı",                39.9110, 41.2820, 2500, 4500.0,  "Yakutiye",    200, 1),
    ("Erzurum Spor Kompleksi",               39.9230, 41.3010, 7000, 13500.0, "Palandöken",  420, 1),
    ("Nenehatun Parkı",                      39.9001, 41.2680, 2000, 3800.0,  "Aziziye",     130, 0),
    ("Dadaşkent Meydanı",                    39.8950, 41.3200, 3500, 6000.0,  "Palandöken",  280, 1),
    ("Şehir Stadyumu",                       39.9150, 41.2950,10000, 20000.0, "Yakutiye",    600, 1),
]

# NOT: Deprem seed verisi kaldırıldı.
# Gerçek veriler Kandilli Rasathanesi API'sinden çekilir: GET /earthquakes/sync

# ---------------------------------------------------------------------------
# Risk motoru (init_db içinde bağımsız kopya — main.py ile senkron)
# ---------------------------------------------------------------------------

_WEIGHTS = {
    "bina_yasi": 0.25, "kat_sayisi": 4.0,
    "zemin_riski": 15.0, "hasar_durumu": 20.0,
    "yasli_sayisi": 3.0, "engelli_sayisi": 5.0, "cocuk_sayisi": 2.0,
}
_RAW_MAX = 55*0.25 + 10*4.0 + 5*15.0 + 5*20.0 + 20*3.0 + 10*5.0 + 25*2.0  # ≈ 328.75


def _raw_score(b: dict) -> float:
    return sum(b[f] * w for f, w in _WEIGHTS.items())


def _normalize(raw: float) -> float:
    return round(min(max(raw / _RAW_MAX * 100, 0.0), 100.0), 2)


def _level(score: float) -> str:
    if score < 25:   return "Düşük Risk"
    elif score < 50: return "Orta Risk"
    elif score < 75: return "Yüksek Risk"
    else:            return "Acil Müdahale"


def _seed_history(conn: sqlite3.Connection, building_id: int, current_norm: float) -> int:
    """Her bina için son 6 aya ait aylık sahte risk geçmişi üretir."""
    random.seed(building_id * 17)
    records = []
    for months_ago in range(6, 0, -1):
        ts = (datetime.now() - timedelta(days=months_ago * 30)).replace(
            hour=9, minute=0, second=0, microsecond=0
        )
        base  = current_norm * (0.78 + months_ago * 0.025)
        noise = random.uniform(-4.0, 4.0)
        hist_norm = round(min(max(base + noise, 0.0), 100.0), 2)
        hist_raw  = round(hist_norm / 100.0 * _RAW_MAX, 2)
        records.append((building_id, hist_raw, hist_norm, _level(hist_norm),
                        ts.isoformat(timespec="seconds")))

    conn.executemany(
        "INSERT INTO risk_history (building_id, raw_score, normalized_score, risk_level, analyzed_at) "
        "VALUES (?, ?, ?, ?, ?)",
        records,
    )
    return len(records)


# ---------------------------------------------------------------------------
# Ana fonksiyon
# ---------------------------------------------------------------------------

def init_database():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print(f"[INFO] Eski {DB_PATH} silindi.")

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    cur = conn.cursor()

    # Tabloları oluştur
    for sql, name in [
        (CREATE_BUILDINGS_SQL,       "buildings"),
        (CREATE_BUILDING_LAYERS_SQL, "building_layers"),
        (CREATE_RESIDENTS_SQL,       "residents"),
        (CREATE_HISTORY_SQL,         "risk_history"),
        (CREATE_ASSEMBLY_POINTS_SQL, "assembly_points"),
        (CREATE_EARTHQUAKES_SQL,     "earthquakes"),     # YENİ
    ]:
        cur.execute(sql)
        print(f"[INFO] '{name}' tablosu oluşturuldu.")

    # Binalar boş — OSM + Tradres + POST /data/bootstrap ile doldurulur
    print("[INFO] 'buildings' tablosu boş — sunucu başlatınca veya POST /data/bootstrap ile doldurulur.")

    # Toplanma alanı seed verisi
    cur.executemany(
        "INSERT INTO assembly_points (ad, lat, lon, kapasite, alan_m2, ilce, doluluk, engelli_uygun) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        ASSEMBLY_POINTS_DATA,
    )
    conn.commit()
    print(f"[INFO] {len(ASSEMBLY_POINTS_DATA)} toplanma alanı eklendi.")

    # Deprem tablosu başlangıçta boş bırakılır.
    # Gerçek veri için: GET /earthquakes/sync  (Kandilli Rasathanesi API)
    print("[INFO] 'earthquakes' tablosu bos olusturuldu — doldurmak icin GET /earthquakes/sync cagirin.")

    conn.close()
    print(f"[OK]  Veritabanı hazır: {DB_PATH}")
    print(f"      Tablolar: buildings, building_layers, residents, risk_history, assembly_points, earthquakes")


if __name__ == "__main__":
    init_database()